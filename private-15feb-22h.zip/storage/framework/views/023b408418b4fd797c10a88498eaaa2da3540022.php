<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
 
<div class="row m-0 p-0">
  <div class="col-6">
    <h2>Showing Category <strong><?php echo e($category->title); ?></strong></h2>
  </div><div class="col-6 text-right">
    
    <a class="btn btn-danger mb-2" href="<?php echo e(URL::previous()); ?>"><i class="fas fa-caret-left"></i></a>
    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-danger mb-2 text-right">Go to categories</a> 
  </div>

</div>

 <?php $__env->endSlot(); ?>
  



<div class="row m-0 p-0 pt-5 pb-5">
  <div class="col-md-2"></div>

  <div class="col-md-8">

    <div class="card">
      <div class="card-body">
        <small class="float-right">ID: <?php echo e($category->id); ?></small>
        <h3 class="card-title"><strong>Title:</strong> <?php echo e($category->{'title'}); ?></h3>
        

        <p><strong>User ID:</strong> <?php echo e($category->user_id); ?></p>
        <p><strong>User Name:</strong> <?php echo e($category->user->name); ?></p>
        <p><strong>Description:</strong> <?php echo e($category->description); ?></p>
        <p><strong>Created at:</strong> <?php echo e($category->created_at); ?></p>

       

      </div>

      <div class="card-footer text-center">
        
        <div class=" btn-group">
          <!-- <div><a href="<?php echo e(route('categories.show',$category->id)); ?>" class="btn btn-warning mr-3">Show <i class="far fa-eye"></i></a></div> -->
          <div><a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-primary mr-3"><i class="far fa-edit"></i> Edit </a></div>

          <div><form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <?php echo method_field('DELETE'); ?>
          <button class="btn btn-danger mr-3" category="submit"><i class="far fa-trash-alt"></i> Delete</button>
          </form></div>
        </div>

      </div>

    </div>

            
            
  

  </div>

  <div class="col-md-2"></div>


</div>
  


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Users/grulovic/code/video-gov/resources/views/category/show.blade.php ENDPATH**/ ?>
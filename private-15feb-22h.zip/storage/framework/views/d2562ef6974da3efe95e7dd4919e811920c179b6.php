<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
 
<div class="row m-0 p-0">
  <div class="col-lg-10">
    <h4>Editing gallery <strong><a href="<?php echo e(route('photos.show',$gallery->id)); ?>"><?php echo e($gallery->name); ?></a></strong> (ID: <?php echo e($gallery->id); ?>)</h4>
  </div>
  <div class="col-lg-2 text-right">
    <a href="<?php echo e(route('photos.index')); ?>" class="btn btn-danger mb-2">Go Back</a> 
  </div>    

</div>

 <?php $__env->endSlot(); ?>

<script type="text/javascript">
$( document ).ready(function() {
  function readURL(input) {
    if (input.files && input.files[0]) {
        $('.carousel-inner').empty();

        for (i = 0; i < input.files.length; i++) {
          console.log(event.target.files[i]);
            var source = URL.createObjectURL(event.target.files[i]);

            if(i==0){
                $('.carousel-inner').append('<div class="carousel-item active" ><p class="mb-0 w-100 text-white bg-info text-center"style="position:absolute;bottom:0px;">'+event.target.files[i]['name']+'</p><img class="d-block " src="' + source +'" style="max-height: 400px; margin-left: auto; margin-right: auto;"></div>');
            }else{
                $('.carousel-inner').append('<div class="carousel-item" ><p class="mb-0 w-100 text-white bg-info text-center"style="position:absolute;bottom:0px;">'+event.target.files[i]['name']+'</p><img class="d-block " src="' + source +'" style="max-height: 400px; margin-left: auto; margin-right: auto;"></div>');
            }
        }

        $("#gallery_preview").show();

    }
}

   $("#gallery").change(function(){
    $("#upload_images").empty();
    readURL(this);
    var upload_images = this.files;

    for(var i=0; i< this.files.length; i++){
        var file = this.files[i];

        $("#upload_images").append('<div class="upload_image card m-2 p-1 bg-light"><div class="text-left"><i class="fas fa-file-image float-left mt-1 mr-2"></i>' + file.name +'</div></div>');
    }

    // $("#upload_images").show();
});


// $("#upload_images").hide();

$("#gallery_preview").hide();





   $(".custom-file-input").on("change", function() {
      // var fileName = $(this).val().split("\\").pop();
      $(this).siblings(".custom-file-label").addClass("selected").html("List of files selected below.");
    });
});



</script>

<div class="row m-0 p-0 pt-5 pb-5">
<div class="col-lg-8">
<form class="row m-0 p-0" action="<?php echo e(route('photos.update', $gallery->id)); ?>" method="POST" name="update_gallery" enctype="multipart/form-data"

>
    <?php echo e(csrf_field()); ?>

     <?php echo method_field('PATCH'); ?>


  <div class="form-group col-lg-6">
        <strong>Gallery Name</strong>
        <input type="text" name="name" class="form-control" placeholder="Enter name of the gallery..." value="<?php echo e($gallery->name); ?>">
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
    </div>

    <div class="form-group col-lg-6">
        <strong>Location</strong>
        <input type="text" name="location" class="form-control" placeholder="Enter the location..." value="<?php echo e($gallery->location); ?>">
        <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
    </div>

     <div class="form-group col-lg-6 mb-3">
      <strong>Photos</strong>

      <div class="custom-file mb-2">
        <input type="file" name="gallery[]" id="gallery" class="custom-file-input" multiple>
        <label class="custom-file-label" for="gallery">List of files selected below...</label>
      </div>
      <span class="text-danger"><?php echo e($errors->first('gallery')); ?></span>


      <div class="w-100 mt-3">
        <div class="form-check form-check-inline">
          <input class="form-check-input checked" type="radio" name="photo_override" id="photo_override1" value="0" checked="">
          <label class="form-check-label" for="inlineRadio1">Add new photos</label>
        </div>

        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="photo_override" id="photo_override2" value="1">
          <label class="form-check-label" for="inlineRadio2">Override current photos</label>
        </div>
      </div>

      <div class="mt-3">
        <strong>Current gallery Photos/Files:</strong>
        <div id="upload_images" class="bg-white border rounded" style="max-height: 242px; overflow-y: scroll;">

        <?php $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="upload_image card m-2 p-1 bg-light">
            <div class="" style="word-break: break-all; ">
             <i class="fas fa-file-image mt-1 mr-2"></i><?php echo e($photo->original_file_name); ?>

            </div>
        </div>
        


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      </div>

    </div>



    

    <div class="col-lg-6">
                   <strong>Categories</strong>
      <div class="input-group  mb-2">

            <select multiple="" class="custom-select" id="category" name="category[]">
              <option value="" <?php if(sizeof($gallery->categories) == 0): ?>selected=""<?php endif; ?>>None</option>
              
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>" 
                    <?php $__currentLoopData = $gallery->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($category->id == $gallery_category->category_id ? 'selected=""' : ''); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  ><?php echo e($category->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              
            </select>
    </div>

    <div class="form-group mb-3">
        <strong>Description</strong>
        <textarea class="form-control" col="4" name="description" placeholder="Enter gallery description..." style="min-height:175px;"><?php echo e($gallery->description); ?></textarea>
        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
    </div>
</div>



<div id="gallery_preview" class="col-lg-12">
    <strong>Gallery Preview</strong>

  <div  id="gallery-preview-carousel" class="carousel slide container-fluid m-0 p-0 bg-dark" data-ride="carousel">

      <div class="carousel-inner">
        
          <div class="carousel-item active" >
            <img class="d-block bg-dark " src="" style="max-height: 400px; margin-left: auto; margin-right: auto;">
          </div>
      
          <div class="carousel-item" >
            <img class="d-block bg-dark" src="" style="max-height: 400px; margin-left: auto; margin-right: auto;">
          </div>

      </div>
      <a class="carousel-control-prev" href="#gallery-preview-carousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#gallery-preview-carousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>

</div>






    <div class="col-6 mt-3">
        <button type="submit" class="btn btn-primary w-100"><i class="fas fa-upload"></i> Edit gallery</button>
    </div>
    <div class="col-6 mt-3">
        <a href="<?php echo e(route('photos.index')); ?>" class="btn btn-danger w-100"><i class="fas fa-ban"></i> Cancel upload</a> 
    </div>
  
</form>

</div>



<div class="col-lg-4">
    <strong>Delete individual photos</strong>

  <div class="card shadow-sm" style="max-height: 520px; overflow-y: scroll;">
  <div class="card-body p-1">
    <?php $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="upload_image card m-2 p-1 bg-light shadow-sm d-flex justify-content-between">
      <div class="row m-0 p-0">
        <div class="col-4 p-0 my-auto"><img class="rounded  "src="<?php echo e(url('uploads/'.$photo->file_name)); ?>" style="width:100px; height: 100px; object-fit: cover; object-position: center;"></div>
        <div class="col-6 p-0 my-auto"><i class="fas fa-file-image mt-1 mr-2 "></i><?php echo e($photo->original_file_name); ?></div>
        <div class="col-2 p-0 my-auto"><form class="" action="<?php echo e(route('photos.destroy_photo', $photo->id)); ?>" method="post" style="max-width:50px;">
          <?php echo e(csrf_field()); ?>

          <?php echo method_field('DELETE'); ?>
          <button class="btn btn-danger" category="submit"><!-- Delete --><i class="far fa-trash-alt"></i></button>
        </form></div>
      </div>
      

      
        
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>

</div>


</div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/grulovic/video_gov/resources/views/gallery/edit.blade.php ENDPATH**/ ?>
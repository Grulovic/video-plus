<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 


<div class="row m-0 p-0">
  <div class="col-9 text-left">
        <h2>Add Category</h2>
    </div>
  <div class="col-3 text-right">
        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-danger mb-2"><i class="fas fa-chevron-left"></i> Go Back</a> 
    </div>
    
</div>

 <?php $__env->endSlot(); ?>

<div class="row m-0 p-0 pt-5 pb-5">
<div class="col-md-2"></div>
<div class="col-md-8">
<form  class="row" action="<?php echo e(route('categories.store')); ?>" method="POST" name="add_category">
    <?php echo e(csrf_field()); ?>

    <input type="text" name="user_id" hidden="" value="<?php echo e(auth()->user()->id); ?>">
      
    <div class="form-group col-6">
        <strong>Title</strong>
        <input type="text" name="title" class="form-control" placeholder="Enter title">
        <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
    </div>


    <div class="form-group col-6">
        <strong>Description</strong>
        <input type="text" name="description" class="form-control" placeholder="Enter description">
        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
    </div>

    






    <div class="col-12 pt-3">
        <div class="w-50 float-left p-1">
            <button type="submit" class="btn btn-primary w-100"><i class="fas fa-archive"></i> Create category</button>
        </div>

        <div class="w-50 float-left p-1">
            <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-danger w-100"><i class="fas fa-ban"></i>  Cancel create</a> 
        </div>
    </div>



    </div>     

</form>

</div>
<div class="col-md-2"></div>
</div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Users/grulovic/code/video-gov/resources/views/category/create.blade.php ENDPATH**/ ?>
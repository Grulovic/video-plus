<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
 
<div class="row m-0 p-0">
  <div class="col-lg-10">
    <h4>Editing Video <strong><a href="<?php echo e(route('videos.show',$video->id)); ?>"><?php echo e($video->name); ?></a></strong> </h4>
  </div>
  <div class="col-lg-2 text-right">
    <a href="<?php echo e(route('videos.index')); ?>" class="btn btn-danger mb-2">Go Back</a> 
  </div>    

</div>

 <?php $__env->endSlot(); ?>

<script type="text/javascript">
$( document ).ready(function() {

   $(document).on("change", "#video", function(evt) {
      var $source = $('#video_preview');
      $source[0].src = URL.createObjectURL(this.files[0]);
      $source.parent()[0].load();
    });

   $(".custom-file-input").on("change", function() {
      var fileName = $(this).val().split("\\").pop();
      
      if(fileName.length > 50){
            var length = 50;
            var fileName = fileName.substring(0, length) + "...";
        }
      
      
      $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    });
});
</script>

<div class="row m-0 p-0 pt-5 pb-5">
<div class="col-md-2"></div>
<div class="col-md-8">
<form class="row m-0 p-0" action="<?php echo e(route('videos.update', $video->id)); ?>" method="POST" name="update_video" enctype="multipart/form-data"

>
  <?php echo e(csrf_field()); ?>

  <?php echo method_field('PATCH'); ?>

    
    <div class="form-group col-6 col-md-6 col-lg-6 mb-3">
        <strong>Name</strong>
        <input type="text" name="name" class="form-control" placeholder="Enter name of the video..." value="<?php echo e($video->name); ?>">
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
    </div>

    <div class="form-group col-6 col-md-6 col-lg-6 mb-3">
        <strong>Location</strong>
        <input type="text" name="location" class="form-control" placeholder="Enter the location..." value="<?php echo e($video->location); ?>">
        <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
    </div>

    <div class="form-group col-lg-6 mb-3 w-100">
      <strong>Video File</strong>
      <div class="custom-file mb-2">
        <input type="file" name="video" id="video" class="custom-file-input">
        <label class="custom-file-label" for="video"><?php echo e(Str::limit($video->original_file_name, 35, $end='...')); ?></label>
      </div>
      <span class="text-danger"><?php echo e($errors->first('video')); ?></span>

      <video controls class="" style="height: 250px;  width: 100%!important; display: block;" >
          <source src="<?php echo e(url('uploads/'.$video->file_name)); ?>" type="<?php echo e($video->mime); ?>" id="video_preview"  controls="true"  preload="metadata" playsinline >
            Your browser does not support HTML5 video.
        </video>

    </div>

   <div class="col-lg-6">
                   <strong>Categories</strong>
      <div class="input-group  mb-2">

            <select multiple="" class="custom-select" id="category" name="category[]">
              <option value="" <?php if(sizeof($video->categories) == 0): ?>selected=""<?php endif; ?>>None</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" 
                  <?php $__currentLoopData = $video->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($category->id == $video_category->category_id ? 'selected=""' : ''); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ><?php echo e($category->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

    
    <div class="form-group mb-3">
        <strong>Description</strong>
        <textarea class="form-control" col="4" name="description" placeholder="Enter video description..." style="min-height:175px;"><?php echo e($video->description); ?></textarea>
        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
    </div>
</div>


    <div class="col-6 mt-3">
        <button type="submit" class="btn btn-primary w-100"><i class="far fa-edit"></i> Edit video</button>
    </div>
    <div class="col-6 mt-3">
        <a href="<?php echo e(route('videos.index')); ?>" class="btn btn-danger w-100"><i class="fas fa-ban"></i> Cancel edit</a> 
    </div>
      
</form>

</div>

<div class="col-md-2"></div>

</div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/grulovic/video_gov/resources/views/video/edit.blade.php ENDPATH**/ ?>
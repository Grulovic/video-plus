
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <script>
        function copyToClipboard(url) {
          var $temp = $("<input>");
          $("body").append($temp);
          $temp.val(url).select();
          document.execCommand("copy");
          $temp.remove();
        }
        </script>
        
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/jquery-ui.js"></script>
    <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.14/themes/base/jquery-ui.css" type="text/css" media="all">
    <script type="text/javascript" src="<?php echo e(asset('js/video-datepicker.js')); ?>"></script>
    <link href="<?php echo e(asset('css/video-datepicker.css')); ?>" rel="stylesheet">

   <?php $__env->slot('header'); ?> 

    <div class="row m-0 p-0">
     <div class="col-lg-12 text-center my-auto m-0 p-0">
 <form class="form-inline row m-0 p-0" action="/photos" method="GET">

  <div class="col-lg-3 text-left">
          <div class="input btn-group mb-2">
            <?php
              $url_components = parse_url($_SERVER['REQUEST_URI']); 
              if( isset($url_components['query']) ){
                $parameters = $url_components['query'];
              }
            ?>
            <a href="<?php echo e(route('photos.index')); ?>?<?php echo e(isset($parameters) ? $parameters : ""); ?>" class="btn btn-secondary active"><i class="fas fa-th"></i></a>
            <a href="<?php echo e(route('photos.list')); ?>?<?php echo e(isset($parameters) ? $parameters : ""); ?>" class="btn btn-secondary "><i class="fas fa-bars"></i></a>
            <a href="<?php echo e(route('photos.create')); ?>" class="btn btn-success"><i class="fas fa-photo-gallery"></i> Upload gallery</a> 
          </div>
  </div>
  <div class="col-lg-3">
  </div>
<div class="col-lg-6 p-0">
  <div class="row m-0 p-0">

    <div class="col-7 col-lg-8 pr-0 text-right"><div class="input-group pr-2  mb-2 ">
      <div class="input-group-prepend">
        <span class="input-group-text" id="basic-addon1"><i class="fas fa-search"></i></span>
      </div>
        <input class="form-control" type="text" name="search" placeholder="Search..." value='<?php echo e((isset(request()->search)) ? request()->search : ""); ?>' focus>
    </div></div>

    <div class="col-5 col-lg-4 pl-0 pr-4 text-right"><div class="btn-group mb-2 ">
      <button type="submit" class="btn btn-primary font-weight-bold " value="Submit">Search <i class="fas fa-search"></i></button>        
      <a href="/photos" class="btn btn-danger"><i class="fas fa-times"></i></a>
    </div></div>
    
  </div>        
</div>

  <div class="col-lg-3">
        <div class="input-group pr-2 mb-2">
          <div class="input-group-prepend">
              <label class="input-group-text" for="from_date"><i class="far fa-calendar-alt"></i></label>
          </div>
          <input class="form-control" type="text" id="datepicker" name="from_date" placeholder="Chose from date..." value="<?php echo e((isset(request()->from_date)) ? request()->from_date : ""); ?>">
        </div>
  </div>
  <div class="col-lg-3">

         <div class="input-group pr-2  mb-2">
            <div class="input-group-prepend">
              <label class="input-group-text" for="vendor"><i class="fas fa-user"></i></label>
            </div>

            <select class="custom-select" id="user" name="user">
              <option value="" <?php echo e((isset(request()->user_id)) ? "selected" : ""); ?>>All users</option>
              <option disabled>------</option>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>" <?php echo e(( request()->user == $user->id) ? "selected" : ""); ?>><?php echo e($user->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
</div><div class="col-lg-3">
          <div class="input-group pr-2  mb-2">
            <div class="input-group-prepend">
              <label class="input-group-text" for="vendor"><i class="fas fa-archive"></i></label>
            </div>

            <select class="custom-select" id="category" name="category">
              <option value="" <?php echo e((isset(request()->user_id)) ? "selected" : ""); ?>>All categories</option>
              <option disabled>------</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e(( request()->category == $category->id) ? "selected" : ""); ?>><?php echo e($category->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>


</div><div class="col-lg-3">
          <div class="input-group pr-2  mb-2">
            <div class="input-group-prepend">
              <label class="input-group-text" for="sort"><i class="fas fa-long-arrow-alt-up"></i><i class="fas fa-long-arrow-alt-down"></i></label>
            </div>

            <select class="custom-select" id="sort" name="sort">
              <option value="new" <?php echo e((request()->sort == "new") ? "selected" : ""); ?>>Newest first</option>
              <option value="old" <?php echo e((request()->sort == "old") ? "selected" : ""); ?>>Oldest first</option>
            </select>
          </div>
</div>
   
        </form>
      </div>
      
    </div>



   <?php $__env->endSlot(); ?>

  <div class="row m-0 p-0 p-3 view-group">
  <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php echo $__env->make('gallery.grid_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <div class="col-lg-12 mt-4">
        <?php echo $galleries->appends(request()->input())->links(); ?>

        
      </div>
  </div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/grulovic/video_gov/resources/views/gallery/grid.blade.php ENDPATH**/ ?>
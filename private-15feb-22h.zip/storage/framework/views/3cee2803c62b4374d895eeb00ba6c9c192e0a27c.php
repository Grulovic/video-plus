<div class="col-sm-6 col-md-4 col-lg-3 col-xl-2 d-flex align-items-stretch p-1">
  <div class="card mb-4 w-100 shadow-sm2">
    <video id="" class="card-img-top bg-dark" style="height: 200px; height:auto; min-width: 100%!important; display: block;" controls="true"  preload="metadata" playsinline muted>
      <!-- preload="none" -->

      <source src="<?php echo e(url('uploads/'.$video->file_name)); ?>#t=0.1" type="<?php echo e($video->mime); ?>">
      Your browser does not support the video tag.
    </video>

      <div class="text-muted text-right w-100 pr-2"><small><?php echo e(date('j. F Y. H:i', strtotime($video->created_at))); ?></small></div>
    <div class="card-body pt-0 pb-0" style="overflow: hidden;">
      <a href="<?php echo e(route('videos.show',$video->id)); ?>" class="text-black"><h3 class="pb-0 mb-0"><?php echo e($video->name); ?></h3></a>
      <p class="text-muted mb-0 pb-0" style=""><?php echo e(Str::limit($video->description, 50, $end='...')); ?></p>
    </div>
     <?php if(!Auth::guest()): ?>
    <div class="card-footer  text-right my-auto">
      
        <div class="btn-group ">
          

          <a href="<?php echo e(route('videos.show',$video->id)); ?>" class="btn btn-sm btn-primary"><i class="far fa-eye"></i> View</a>
          <button class="btn btn-sm btn-info" onclick="copyToClipboard('<?php echo e(route('videos.show',$video->id)); ?>')"><i class="far fa-share-square"></i></button>
          
         
          <a href="<?php echo e(route('videos.download',$video->id)); ?>" class="btn btn-sm btn-success"><i class="fas fa-download"></i></a>
          <a href="<?php echo e(route('videos.edit',$video->id)); ?>" class="btn btn-sm btn-warning"><i class="far fa-edit"></i></a>

          <form class="" action="<?php echo e(route('videos.destroy', $video->id)); ?>" method="post"
            >
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('DELETE'); ?>
            <button  type="submit" class="btn btn-sm btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
            data-toggle="tooltip" data-placement="top" title="Delete video">
            <!-- Delete --><i class="far fa-trash-alt"></i></button>
          </form>
          

        </div>
      </div>
<?php endif; ?>
  </div>
</div><?php /**PATH /Users/grulovic/code/video-gov/resources/views/home/video_card.blade.php ENDPATH**/ ?>
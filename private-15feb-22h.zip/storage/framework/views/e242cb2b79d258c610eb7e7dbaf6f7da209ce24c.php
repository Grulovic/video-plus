<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 


<div class="row m-0 p-0">
  <div class="col-6 text-left">
        <h4>Add Gallery</h4>
    </div>
  <div class="col-6 text-right">
        <a href="<?php echo e(route('photos.index')); ?>" class="btn btn-danger mb-2">Go Back</a> 
    </div>
    
</div>

 <?php $__env->endSlot(); ?>


<script type="text/javascript">
$( document ).ready(function() {
  function readURL(input) {
    if (input.files && input.files[0]) {
        $('.carousel-inner').empty();

        for (i = 0; i < input.files.length; i++) {
          console.log(event.target.files[i]);
            var source = URL.createObjectURL(event.target.files[i]);

            if(i==0){
                $('.carousel-inner').append('<div class="carousel-item active" ><p class="mb-0 w-100 text-white bg-info text-center"style="position:absolute;bottom:0px;">'+event.target.files[i]['name']+'</p><img class="d-block " src="' + source +'" style="max-height: 400px; margin-left: auto; margin-right: auto;"></div>');
            }else{
                $('.carousel-inner').append('<div class="carousel-item" ><p class="mb-0 w-100 text-white bg-info text-center"style="position:absolute;bottom:0px;">'+event.target.files[i]['name']+'</p><img class="d-block " src="' + source +'" style="max-height: 400px; margin-left: auto; margin-right: auto;"></div>');
            }
        }

        $("#gallery_preview").show();

    }
}

   $("#gallery").change(function(){
    $("#upload_images").empty();
    readURL(this);
    var upload_images = this.files;

    for(var i=0; i< this.files.length; i++){
        var file = this.files[i];

        $("#upload_images").append('<div class="upload_image card m-2 p-1 bg-light"><div class="text-left"><i class="fas fa-file-image float-left mt-1 mr-2"></i>' + file.name +'</div></div>');
    }

    // $("#upload_images").show();
});


// $("#upload_images").hide();

$("#gallery_preview").hide();





   $(".custom-file-input").on("change", function() {
      // var fileName = $(this).val().split("\\").pop();
      $(this).siblings(".custom-file-label").addClass("selected").html("List of files selected below.");
    });
});



</script>

<div class="row m-0 p-0 pt-5 pb-5">
<div class="col-md-2"></div>
<div class="col-md-8">
<form class="row" action="<?php echo e(route('photos.store')); ?>" method="POST" name="add_gallery" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>



  <div class="form-group col-lg-6">
        <strong>Gallery Name</strong>
        <input type="text" name="name" class="form-control" placeholder="Enter name of the gallery..." value="<?php echo e(old('name')); ?>" required>
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
    </div>

    <div class="form-group col-lg-6">
        <strong>Location</strong>
        <input type="text" name="location" class="form-control" placeholder="Enter the location..." value="<?php echo e(old('location')); ?>">
        <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
    </div>

     <div class="form-group col-lg-6 mb-3">
      <strong>Photos</strong>
      <div class="custom-file mb-2">
        <input type="file" name="gallery[]" id="gallery" class="custom-file-input" multiple required>
        <label class="custom-file-label" for="gallery">Select image files...</label>
      </div>
      <span class="text-danger"><?php echo e($errors->first('gallery')); ?></span>


      <strong>File list:</strong>
      <div id="upload_images" class="card" style="max-height: 242px; overflow-y: scroll;">
      <div class="upload_image card m-2 p-1" style="background-color:#ea868f; "><div class="text-left"><i class="fas fa-file-image float-left mt-1 mr-2"></i><i class="fas fa-exclamation-circle"></i> No photos selected.</div></div>
      </div>

    </div>

    

    <div class="col-lg-6">
                   <strong>Categories</strong>
      <div class="input-group  mb-2">

            <select multiple="" class="custom-select" id="category" name="category[]">
              <option value="" selected="">None</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    </div>

    <div class="form-group mb-3">
        <strong>Description</strong>
        <textarea class="form-control" col="4" name="description" placeholder="Enter gallery description..." style="min-height:175px;"><?php echo e(old('description')); ?></textarea>
        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
    </div>
</div>



<div id="gallery_preview" class="col-lg-12">
    <strong>Gallery Preview</strong>

  <div  id="gallery-preview-carousel" class="carousel slide container-fluid m-0 p-0 bg-dark" data-ride="carousel">

      <div class="carousel-inner">
        
          <div class="carousel-item active" >
            <img class="d-block bg-dark " src="" style="max-height: 400px; margin-left: auto; margin-right: auto;">
          </div>
      
          <div class="carousel-item" >
            <img class="d-block bg-dark" src="" style="max-height: 400px; margin-left: auto; margin-right: auto;">
          </div>

      </div>
      <a class="carousel-control-prev" href="#gallery-preview-carousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#gallery-preview-carousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>

</div>






    <div class="col-6 mt-3">
        <button type="submit" class="btn btn-primary w-100"><i class="fas fa-upload"></i> Upload gallery</button>
    </div>
    <div class="col-6 mt-3">
        <a href="<?php echo e(route('photos.index')); ?>" class="btn btn-danger w-100"><i class="fas fa-ban"></i> Cancel upload</a> 
    </div>
    


</form>

</div>
<div class="col-md-2"></div>


</div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/grulovic/video_gov/resources/views/gallery/create.blade.php ENDPATH**/ ?>
<div class="col-lg-12 m-0 p-0">
  <div class="card shadow-sm mb-4">
    <div class="row no-gutters bg-dark">
        
        <div class="col-lg-5 h-100 bg-dark my-auto" style="">
          <video id="" class="card-img bg-dark" style="min-height:100%; width: 100%!important; display: block;" controls="true"  preload="metadata" playsinline muted>
            <!-- preload="none" -->
            <source src="<?php echo e(url('uploads/'.$video->file_name)); ?>#t=0.1" type="<?php echo e($video->mime); ?>">
            Your browser does not support the video tag.
          </video>
        </div>

        <div class="col-lg-7 bg-white">
          <div class="row m-0 p-0  h-100">
            <div class="col-12 pt-2 " >
              <div class="text-muted text-right w-100 pr-2"><small><?php echo e(date('j. F Y. H:i', strtotime($video->created_at))); ?></small></div>
              <a href="<?php echo e(route('videos.show',$video->id)); ?>" class="text-black"><h2><?php echo e($video->name); ?></h2></a>
                <p class="text-muted">
                  <?php if( sizeof($video->categories) > 0 ): ?>
                    <?php $__currentLoopData = $video->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($category->category->title); ?> 
                      <?php if(!$loop->last): ?> | <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    Video categories not assigned.
                  <?php endif; ?>
                </p>
            </div>
          

            <div class="col-lg-5">
                <p class="mb-0 pb-0"><strong>Video uploaded by:</strong> <?php echo e($video->user->name); ?></p>
                <p class="mb-0 pb-0"><strong>Location:</strong> <?php echo e($video->location); ?></p>
                <p class="mb-0 pb-0"><strong>Date of upload:</strong> <?php echo e($video->created_at); ?></p>
                <br>
                <p class="mb-0 pb-0"><strong>File type:</strong> <?php echo e($video->mime); ?></p>
                <p class="mb-0 pb-0"><strong>File size:</strong> <?php echo e($video->size); ?></p>
                <br>
            </div>

            <div class="col-lg-7" style="border-radius: 0px 0px 0.25rem  0px; ">
               <strong>Description:</strong>
                <p class="mb-0 pb-0"><?php echo e($video->description); ?></p>
                <br>
            </div>

             <div class="col-lg-12 card-footer text-center text-lg-right w-100 align-self-end pl-1 pr-3"  style="">
              <div class="btn-group">
                <a href="<?php echo e(route('videos.show',$video->id)); ?>" class="btn btn-sm  btn-primary"><i class="far fa-eye"></i> View</a>
                <button class="btn btn-sm btn-info" onclick="copyToClipboard('<?php echo e(route('videos.show',$video->id)); ?>')"><i class="far fa-share-square"></i> Copy link</button>
                
                <a href="<?php echo e(route('videos.download',$video->id)); ?>" class="btn btn-sm  btn-success"><i class="fas fa-download"></i> Download</a>
                <a href="<?php echo e(route('videos.edit',$video->id)); ?>" class="btn btn-sm  btn-warning"><i class="far fa-edit"></i> Edit</a>

                <form class="" action="<?php echo e(route('videos.destroy', $video->id)); ?>" method="post"
                  >
                  <?php echo e(csrf_field()); ?>

                  <?php echo method_field('DELETE'); ?>
                  <button  type="submit" class="btn btn-sm  btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
                  data-toggle="tooltip" data-placement="top" title="Delete video">
                  <i class="far fa-trash-alt"></i> Delete</button>
                </form>

              </div>
            </div>


          </div>
        </div>

    </div>
</div>
</div><?php /**PATH /home/grulovic/video_gov/resources/views/video/list_card.blade.php ENDPATH**/ ?>


<x-app-layout>
    <x-slot name="header">
   

 <div class="row  m-0 p-0">
  
  <div class="col-lg-3  text-left">
    <h2>Category List:</h2>
  </div>



  <div class="col-lg-9 text-center">

    <a href="{{ route('lives.create') }}" class="btn btn-success float-right ml-1 "><i class="fas fa-archive"></i> Add Category</a> 

  </div>

  
</div>


    </x-slot>

 <div class="row m-0 p-0 pt-5 pb-5">
      <div class="col-md-1"></div>

      <div class="col-md-10 p-0" style="padding-right: 0; overflow-x: auto;">          
        <table class="table table-bordered sortable" id="laravel_crud">
         <thead>
            <tr class="thead-dark">
               <th colspan="3" class="text-center">Action</th>

                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>User ID</th>
                <th>User Name</th>
                <th>Created at</th>
            </tr>
         </thead>
         <tbody>
            @foreach($lives as $live)
            <tr class=" bg-white " >
              
              <td class="text-center  bg-dark text-white" style="border-color:#454d55;">
                <a href="{{ route('lives.show',$live->id)}}" class="btn btn-warning"><!-- Show --> <i class="far fa-eye"></i></a>
              </td>
               <td class="text-center  bg-dark text-white" style="border-color:#454d55;">
                <a href="{{ route('lives.edit',$live->id)}}" class="btn btn-primary"><!-- Edit --> <i class="far fa-edit"></i></a></td>
               <td class="text-center  bg-dark text-white" style="border-color:#454d55;">
               <form action="{{ route('lives.destroy', $live->id)}}" method="post">
                {{ csrf_field() }}
                @method('DELETE')
                <button class="btn btn-danger" live="submit"><!-- Delete --><i class="far fa-trash-alt"></i></button>
              </form>
              </td>

               <td class="text-center  bg-dark text-white" style="border-color:#454d55;">{{ $live->id }}</td>
              

              <td>{{ $live->title }}</td>
              <td>{{ $live->description }}</td>                
              <tD>{{ $live->user->id }}</td>
              <td>{{ $live->user->name }}</tD>
              <td>{{ $live->created_at }}</td>
              


              

            </tr>

            @endforeach
 
            @if(count($lives) < 1)
              <tr class="bg-white">
               <td colspan="13" class="text-center">There are no live available yet!</td>
              </td>
            </tr>
            @endif
         </tbody>
        </table>
        {!! $lives->appends(request()->input())->links() !!}
     </div> 
      <div class="col-md-1"></div>


     


 </div>




 </x-app-layout>
<x-app-layout>
    <x-slot name="header">
 
<div class="row m-0 p-0">
  <div class="col-lg-10">
    <h4>Editing Video <strong><a href="{{ route('videos.show',$video->id) }}">{{$video->name}}</a></strong> {{--(ID: {{ $video->id }})--}}</h4>
  </div>
  <div class="col-lg-2 text-right">
    <a href="{{ route('videos.index') }}" class="btn btn-danger mb-2">Go Back</a> 
  </div>    

</div>

</x-slot>

<script type="text/javascript">
$( document ).ready(function() {

   $(document).on("change", "#video", function(evt) {
      var $source = $('#video_preview');
      $source[0].src = URL.createObjectURL(this.files[0]);
      $source.parent()[0].load();
    });

   $(".custom-file-input").on("change", function() {
      var fileName = $(this).val().split("\\").pop();
      
      if(fileName.length > 50){
            var length = 50;
            var fileName = fileName.substring(0, length) + "...";
        }
      
      
      $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    });
});
</script>

<div class="row m-0 p-0 pt-5 pb-5">
<div class="col-md-2"></div>
<div class="col-md-8">
<form class="row m-0 p-0" action="{{ route('videos.update', $video->id) }}" method="POST" name="update_video" enctype="multipart/form-data"

>
  {{ csrf_field() }}
  @method('PATCH')

    
    <div class="form-group col-6 col-md-6 col-lg-6 mb-3">
        <strong>Name</strong>
        <input type="text" name="name" class="form-control" placeholder="Enter name of the video..." value="{{ $video->name }}">
        <span class="text-danger">{{ $errors->first('name') }}</span>
    </div>

    <div class="form-group col-6 col-md-6 col-lg-6 mb-3">
        <strong>Location</strong>
        <input type="text" name="location" class="form-control" placeholder="Enter the location..." value="{{ $video->location }}">
        <span class="text-danger">{{ $errors->first('location') }}</span>
    </div>

    <div class="form-group col-lg-6 mb-3 w-100">
      <strong>Video File</strong>
      <div class="custom-file mb-2">
        <input type="file" name="video" id="video" class="custom-file-input">
        <label class="custom-file-label" for="video">{{ Str::limit($video->original_file_name, 35, $end='...')}}</label>
      </div>
      <span class="text-danger">{{ $errors->first('video') }}</span>

      <video controls class="" style="height: 250px;  width: 100%!important; display: block;" >
          <source src="{{ url('uploads/'.$video->file_name) }}" type="{{$video->mime}}" id="video_preview"  controls="true"  preload="metadata" playsinline >
            Your browser does not support HTML5 video.
        </video>

    </div>

   <div class="col-lg-6">
                   <strong>Categories</strong>
      <div class="input-group  mb-2">

            <select multiple="" class="custom-select" id="category" name="category[]">
              <option value="" @if(sizeof($video->categories) == 0)selected=""@endif>None</option>
              @foreach($categories as $category)
                <option value="{{$category->id}}" 
                  @foreach($video->categories as $video_category)
                            {{ $category->id == $video_category->category_id ? 'selected=""' : '' }}
                  @endforeach
                >{{$category->title}}</option>
              @endforeach
            </select>
          </div>

    
    <div class="form-group mb-3">
        <strong>Description</strong>
        <textarea class="form-control" col="4" name="description" placeholder="Enter video description..." style="min-height:175px;">{{ $video->description }}</textarea>
        <span class="text-danger">{{ $errors->first('description') }}</span>
    </div>
</div>


    <div class="col-6 mt-3">
        <button type="submit" class="btn btn-primary w-100"><i class="far fa-edit"></i> Edit video</button>
    </div>
    <div class="col-6 mt-3">
        <a href="{{ route('videos.index') }}" class="btn btn-danger w-100"><i class="fas fa-ban"></i> Cancel edit</a> 
    </div>
      
</form>

</div>

<div class="col-md-2"></div>

</div>

</x-app-layout>
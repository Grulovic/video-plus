<div class="col-sm-6 col-md-4 col-lg-3 col-xl-3 d-flex align-items-stretch p-1">
  <div class="card mb-4 w-100 shadow-sm">
    <video id="" class="card-img-top bg-dark" style="height: 190px; height:auto; min-width: 100%!important; display: block;" controls="true"  preload="metadata" playsinline muted>
      <!-- preload="none" -->

      <source src="{{ url('uploads/'.$video->file_name) }}#t=0.1" type="{{$video->mime}}">
      Your browser does not support the video tag.
    </video>

      <div class="text-muted text-right w-100 pr-2"><small>{{ date('j. F Y. H:i', strtotime($video->created_at)) }}</small></div>
    <div class="card-body pt-0" style="overflow: hidden;">
      <a href="{{ route('videos.show',$video->id)}}" class="text-black"><h3 class="pb-0 mb-0">{{ Str::limit($video->name, 35, $end='...')}}</h3></a>
      <p class="text-muted" style=" white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><small>
        @if(sizeof($video->categories) > 0)
          @foreach($video->categories as $category)
          {{$category->category->title}} 
            @if(!$loop->last) | @endif
          @endforeach
        @else
          No categories
        @endif
      </small></p>

      <p class="text-muted mb-0 pb-0" style="">{{ Str::limit($video->description, 70, $end='...')}}</p>
    </div>
    
    <div class="card-footer  text-right">
        <div class="btn-group ">
          <a href="{{ route('videos.show',$video->id)}}" class="btn btn-sm btn-primary"><i class="far fa-eye"></i> View</a>
          <button class="btn btn-sm btn-info" onclick="copyToClipboard('{{ route('videos.show',$video->id)}}')"><i class="far fa-share-square"></i></button>
          
          <a href="{{ route('videos.download',$video->id)}}" class="btn btn-sm btn-success"><i class="fas fa-download"></i></a>
          <a href="{{ route('videos.edit',$video->id)}}" class="btn btn-sm btn-warning"><i class="far fa-edit"></i></a>

          <form class="" action="{{ route('videos.destroy', $video->id)}}" method="post"
            >
            {{ csrf_field() }}
            @method('DELETE')
            <button  type="submit" class="btn btn-sm btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
            data-toggle="tooltip" data-placement="top" title="Delete video">
            <!-- Delete --><i class="far fa-trash-alt"></i></button>
          </form>

        </div>
      </div>

  </div>
</div>
<style type="text/css">
.carousel{
	background: rgb(199,54,61);
	background: linear-gradient(135deg, rgba(199,54,61,1) 0%, rgba(13,64,119,1) 100%);
}
.carousel-item{
	height: 700px;
}	
@media only screen and (max-width: 991px) {
  #home_carousel {
    margin-top:65px!important;
  }
}
 .text-shadow-sm:not(.btn){
    /*text-shadow: -1px 1px 3px rgba(150, 150, 150, 1);*/
    text-shadow: -2px 2px 2px rgba(0,0,0,0.75)!important;
  }
</style>
<div id="home_carousel_wrapper" class="row m-0 p-0">
  <div class="col-lg-12 p-0">
    
    <div id="home_carousel" class="carousel slide shadow-lg" data-ride="carousel">
	  <ol class="carousel-indicators">
	  	@foreach($carausel as $item)
		    <li data-target="#home_carousel" data-slide-to="{{$loop->index}}" @if($loop->first)class="active"@endif></li>
		@endforeach
	  </ol>
	  <div class="carousel-inner">

	  	@foreach($carausel as $item)
	  		@if(class_basename($item) == "Video")
		    <div class="carousel-item {{ ($loop->first)?'active':'' }}" style="">
		    	<div class="container h-100" style="max-width: 85%;">
		      <div class="row m-0 p-0 h-100" style="">
		      	
		      	
		      	<div class="col-lg-6 my-lg-auto text-white bg-info2 order-lg-1 order-2">
		      		<div>
		      		<h2 class="text-shadow-sm">{{ Str::limit($item->name, 80, $end='...')}}</h2>
				      <p class="text-white text-shadow-sm">
				        @if( sizeof($item->categories) > 0 )
				          @foreach($item->categories as $category)
				          {{$category->category->title}} 
				            @if(!$loop->last) | @endif
				          @endforeach
				        @endif
				      </p>
				      <p class="mb-0 pb-0 text-shadow-sm">{{ Str::limit($item->description, 140, $end='...')}}</p>
				      
				      <a href="{{ route('videos.show',$item->id)}}" class="btn btn-primary mt-5"><i class="far fa-eye"></i> Go to Video</a>

				      </div>
		      	</div>


		      	<div class="col-lg-6 my-auto pt-2 pb-2 bg-warning2  order-lg-2 order-1">
		      		<video id="" class="card-img-top rounded-left shadow-sm bg-dark" style="max-height: 400px;  display: block;" controls="true"  preload="metadata" playsinline >
				      <source src="{{ url('uploads/'.$item->file_name) }}#t=0.1" type="{{$item->mime}}">
				      Your browser does not support the video tag.
				    </video>
		      	</div>

		      </div>
		      </div>
		    </div>
		    @else
		    
    		    @if(sizeof($item->photos) > 0)
    		    <div class="carousel-item {{ ($loop->first)?'active':'' }}" style="
    		    background-color:rgba(0,0,0,0.3);
    		    background-image:url({{url('uploads/'.$item->photos[0]->file_name)}})!important; 
    		    background-size:cover;
    		    background-position:center;
    		    background-repeat:no-repeat;
    
    		    ">
    		    	<div class="container h-100" style="max-width: 85%;">
    	    			<div class="row m-0 p-0 h-100" style="">
      					<div class="col-lg-12 my-auto text-white bg-info2">
    		    		<h2 class="text-shadow-sm">{{ Str::limit($item->name, 80, $end='...')}}</h2>
    				      <p class="text-white text-shadow-sm">
    				        @if( sizeof($item->categories) > 0 )
    				          @foreach($item->categories as $category)
    				          {{$category->category->title}} 
    				            @if(!$loop->last) | @endif
    				          @endforeach
    				        @endif
    				      </p>
    				      <p class="mb-0 pb-0 text-shadow-sm">{{ Str::limit($item->description, 140, $end='...')}}</p>
    				      
    				      <a href="{{ route('photos.show',$item->id)}}" class="btn btn-primary mt-5"><i class="far fa-eye"></i> Go to Gallery</a>
    		   		</div>
    		   		</div>
    		   		</div>
    		   </div>
    		    @endif
		    @endif
		@endforeach

	    


	  </div>




	  <a class="carousel-control-prev" href="#home_carousel" role="button" data-slide="prev">
	    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
	    <span class="sr-only">Previous</span>
	  </a>
	  <a class="carousel-control-next" href="#home_carousel" role="button" data-slide="next">
	    <span class="carousel-control-next-icon" aria-hidden="true"></span>
	    <span class="sr-only">Next</span>
	  </a>



	</div>
    
  </div>
</div>
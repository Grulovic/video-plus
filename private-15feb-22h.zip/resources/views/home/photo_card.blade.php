<div class="col-sm-6 col-md-4 col-lg-3 col-xl-3 d-flex align-items-stretch p-1">
  <div class="card mb-4 w-100 shadow-sm">

    <a href="{{ route('photos.show',$gallery->id)}}"><img src="{{ url('uploads/'.$gallery->photos[0]->file_name) }}" class="card-img-top bg-dark" style="height: 250px; min-width: 100%!important; display: block; object-fit:cover;"></a>

    
      <div class="text-muted text-right w-100 pr-2"><small>{{ date('j. F Y. H:i', strtotime($gallery->created_at)) }}</small></div>
    <div class="card-body pt-0" style="overflow: hidden;">
      <a href="{{ route('photos.show',$gallery->id)}}" class="text-black"><h4 class="pb-0 mb-0">{{ Str::limit($gallery->name, 40, $end='...')}}</h4></a>

      <p class="text-muted mb-0 pb-0" style="">{{ Str::limit($gallery->description, 50, $end='...')}}</p>
    </div>
    @if (!Auth::guest())
    <div class="card-footer  text-right">
        <div class="btn-group ">
          <a href="{{ route('photos.show',$gallery->id)}}" class="btn btn-sm btn-primary"><i class="far fa-eye"></i> View</a>
          <button class="btn btn-sm btn-info" onclick="copyToClipboard('{{ route('photos.show',$gallery->id)}}')"><i class="far fa-share-square"></i></button>
          
          
          <a href="{{ route('photos.download',$gallery->id)}}" class="btn btn-sm btn-success"><i class="fas fa-download"></i></a>
          <a href="{{ route('photos.edit',$gallery->id)}}" class="btn btn-sm btn-warning"><i class="far fa-edit"></i></a>

          <form class="" action="{{ route('photos.destroy', $gallery->id)}}" method="post"
            >
            {{ csrf_field() }}
            @method('DELETE')
            <button  type="submit" class="btn btn-sm btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
            data-toggle="tooltip" data-placement="top" title="Delete gallery">
            <!-- Delete --><i class="far fa-trash-alt"></i></button>
          </form>
         

        </div>
      </div>
       @endif
  </div>
</div>
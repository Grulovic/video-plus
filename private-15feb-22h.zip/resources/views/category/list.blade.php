

<x-app-layout>
    <x-slot name="header">
   

 <div class="row  m-0 p-0">
  
  <div class="col-lg-3  text-left">
    <h2>Category List:</h2>
  </div>



  <div class="col-lg-9 text-center">

    <a href="{{ route('categories.create') }}" class="btn btn-success float-right ml-1 "><i class="fas fa-archive"></i> Add Category</a> 

  </div>

  
</div>


    </x-slot>

 <div class="row m-0 p-0 pt-5 pb-5">
      <div class="col-md-1"></div>

      <div class="col-md-10 p-0" style="padding-right: 0; overflow-x: auto;">          
        <table class="table table-bordered sortable" id="laravel_crud">
         <thead>
            <tr class="thead-dark">
               <th colspan="3" class="text-center">Action</th>

                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>User ID</th>
                <th>User Name</th>
                <th>Created at</th>
            </tr>
         </thead>
         <tbody>
            @foreach($categories as $category)
            <tr class=" bg-white " >
              
              <td class="text-center  bg-dark text-white" style="border-color:#454d55;">
                <a href="{{ route('categories.show',$category->id)}}" class="btn btn-warning"><!-- Show --> <i class="far fa-eye"></i></a>
              </td>
               <td class="text-center  bg-dark text-white" style="border-color:#454d55;">
                <a href="{{ route('categories.edit',$category->id)}}" class="btn btn-primary"><!-- Edit --> <i class="far fa-edit"></i></a></td>
               <td class="text-center  bg-dark text-white" style="border-color:#454d55;">
               <form action="{{ route('categories.destroy', $category->id)}}" method="post">
                {{ csrf_field() }}
                @method('DELETE')
                <button class="btn btn-danger" category="submit"><!-- Delete --><i class="far fa-trash-alt"></i></button>
              </form>
              </td>

               <td class="text-center  bg-dark text-white" style="border-color:#454d55;">{{ $category->id }}</td>
              

              <td>{{ $category->title }}</td>
              <td>{{ $category->description }}</td>                
              <tD>{{ $category->user->id }}</td>
              <td>{{ $category->user->name }}</tD>
              <td>{{ $category->created_at }}</td>
              


              

            </tr>

            @endforeach
 
            @if(count($categories) < 1)
              <tr class="bg-white">
               <td colspan="13" class="text-center">There are no category available yet!</td>
              </td>
            </tr>
            @endif
         </tbody>
        </table>
     </div> 
      <div class="col-md-1"></div>

  <div class="col-md-1"></div>
      <div class="col-md-10">
          {!! $categories->appends(request()->input())->links() !!}
      </div>
      <div class="col-md-1"></div>

     


 </div>




 </x-app-layout>
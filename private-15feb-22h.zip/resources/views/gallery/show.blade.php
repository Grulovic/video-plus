<x-app-layout>
    <x-slot name="header">
 
      <div class="row m-0 p-0">
        
        <div class="col-lg-10">
          <h4>Showing Gallery <strong>{{$gallery->name}}</strong> {{--(ID: {{ $gallery->id }})--}}</h4>
        </div>
        
        <div class="col-lg-2 text-right">
          <a class="btn btn-danger mb-2" href="{{ URL::previous() }}"><i class="fas fa-caret-left"></i></a>
          <a href="{{ route('photos.index') }}" class="btn btn-danger mb-2 text-right">Go to Videos</a> 
        </div>
        
        
      </div>

    </x-slot>


<style type="text/css">
  #vide-col .card-img-top{
    border-radius:0.25rem 0 0 0.25rem; 
  }

  #desc-card-col .card{
    border-radius:0 0.25rem 0.25rem 0;
  }

  @media only screen and (max-width: 991px) {
    #vide-col .card-img-top{
      border-radius:0.25rem 0.25rem 0 0; 
    }

    #desc-card-col .card{
      border-radius:0 0 0.25rem 0.25rem;
    }
  }


</style>



<div class="container">
<div class="row pt-5 pb-5 pl-1 pr-1">
  
<div id="vide-col" class="col-lg-7 d-flex align-items-stretch p-0 ">


  <div id="gallery{{$gallery->id}}" class="carousel slide card-img-top rounded-left shadow-sm bg-dark" data-ride="carousel" style="max-height: 100%; width: 100%!important; display: block;">
    <ol class="carousel-indicators">
      @foreach($gallery->photos as $photo)
      <li data-target="#gallery{{$gallery->id}}" data-slide-to="{{ $loop->index }}" {{ $loop->first ? 'class="active"':'' }}></li>
      @endforeach
    </ol>
    <div class="carousel-inner  rounded-left text-center h-100  my-auto" style="min-height: 400px;">

      @foreach($gallery->photos as $photo)
      <div class="carousel-item {{ $loop->first ? 'active':'' }} h-100 rounded-left text-center h-100 my-auto" 
        style="background-image:url({{ url('uploads/'.$photo->file_name) }}); background-size:contain; background-position: center; background-repeat:no-repeat; ">
        <div>
        <p class="mb-0 w-100 text-white bg-info text-center"style="position:absolute;bottom:0px;">{{ $photo->file_name }}</p>
        <img src="{{ url('uploads/'.$photo->file_name) }}" class="d-none text-center" style="max-height: 500px; width:auto;  margin-left: auto; margin-right: auto;">
        </div>
      </div>
      @endforeach

      

    </div>
    <a class="carousel-control-prev " href="#gallery{{$gallery->id}}" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next text-shadow-sm" href="#gallery{{$gallery->id}}" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


</div>

<div id="desc-card-col" class="col-lg-5 d-flex align-items-stretch p-0 ">
  <div class="card w-100  shadow-sm" style="">
    

    <div class="card-body">
      <h2>{{$gallery->name}}</h2>
      <p class="text-muted">
        @if( sizeof($gallery->categories) > 0 )
          @foreach($gallery->categories as $category)
          {{$category->category->title}} 
            @if(!$loop->last) | @endif
          @endforeach
        @else
          Video categories not assigned.
        @endif
      </p>
               <p class="text-muted mb-0 pb-0"># of photos: {{ sizeof($gallery->photos) }}</p>

      
      <p class="mb-0 pb-0"><strong>Video uploaded by:</strong> {{ $gallery->user->name}}</p>

      <p class="mb-0 pb-0"><strong>Location:</strong> {{ $gallery->location}}</p>
      <p class="mb-0 pb-0"><strong>Date of upload:</strong> {{ $gallery->created_at}}</p>
      <br><strong>Description:</strong>
      <p class="mb-0 pb-0">{{ $gallery->description}}</p>
      <br>
                      <strong>List of Photos:</strong>
                <div id="upload_images" class="bg-white border rounded" style="max-height: 242px; overflow-y: scroll;">

                @foreach($gallery->photos as $photo)
                <div class="upload_image card m-2 p-1 bg-light" style="word-break: break-all; "><div class="text-left"><i class="fas fa-file-image float-left mt-1 mr-2"></i>{{$photo->original_file_name}}</div></div>
                @endforeach

                </div>

    
      <br>


    </div>
    
    <div class="card-footer text-right">
        <!-- <input type="text" value="{{ route('photos.show',$gallery->id)}}" id="current_gallery_url"> -->

        <div class="btn-group">
          <button class="btn btn-sm btn-info" onclick="copyToClipboard('{{ route('photos.show',$gallery->id)}}')"><i class="far fa-share-square"></i> Copy Link</button>
          <!-- <a href="{{ route('photos.show',$gallery->id)}}" class="btn btn-sm btn-outline-primary"><i class="far fa-eye"></i> View</a> -->
          <a href="{{ route('photos.download',$gallery->id)}}" class="btn btn-sm btn-success"><i class="fas fa-download"></i> Download</a>
          <a href="{{ route('photos.edit',$gallery->id)}}" class="btn btn-sm btn-warning text-white"><i class="far fa-edit"></i> Edit</a>

          <form class="" action="{{ route('photos.destroy', $gallery->id)}}" method="post"
            >
            {{ csrf_field() }}
            @method('DELETE')
            <button  type="submit" class="btn btn-sm btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
            data-toggle="tooltip" data-placement="top" title="Delete gallery">
            <!-- Delete --><i class="far fa-trash-alt"></i> Delete</button>
          </form>


          
        </div>
      </div>

  </div>
</div>


</div>
</div>




</x-app-layout>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Photo;
use App\Models\Gallery;
use App\Models\Video;
use App\Models\History;



class HomeController extends Controller
{
    public function index(){
    
        $list_of_files = scandir(public_path()."/uploads/");
        // ->whereIn('file_name', $list_of_files);
        
    	$videos_carausel = Video::orderBy('id', 'desc')->whereIn('file_name', $list_of_files)->take(3)->get();
    	$photos_carausel = Gallery::orderBy('id', 'desc')->has('photos', '>' , 0)->take(3)->get();
    	$merged = $videos_carausel->merge($photos_carausel);
        $data['carausel'] = $merged->shuffle();
        
        // dd(class_basename($data['carausel'][0]->photos[0]->file_name));

    	
        $data['latest_videos'] = Video::orderBy('id', 'desc')->whereIn('file_name', $list_of_files)->take(4)->get();
        $data['latest_photos'] = Gallery::orderBy('id', 'desc')->has('photos', '>' , 0)->take(4)->get();

        // dd($data['carausel']);

    	return view('home',$data);
    }
}
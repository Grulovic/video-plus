<?php

namespace App\Http\Controllers;

use App\Models\Gallery;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Photo;
use App\Models\Category;
use App\Models\GalleryCategory;
use App\Models\History;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Response;
use Redirect;
use Session;
use URL;
use ZipArchive;

class GalleryController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
    
    public function index()
    {
        $data['galleries'] = $this->search()->has('photos', '>' , 0)->paginate(12);
        $data['users'] =  User::select('id','name')->orderBy('id','asc')->get();
        $data['categories'] =  Category::select('id','title')->orderBy('title','asc')->get();

        return view('gallery.grid',$data);
    }

    public function list()
    {
        $data['galleries'] = $this->search()->has('photos', '>' , 0)->paginate(6);
        $data['users'] =  User::select('id','name')->orderBy('id','asc')->get();
        $data['categories'] =  Category::select('id','title')->orderBy('title','asc')->get();

        return view('gallery.list',$data);
    }
    

    public function create()
    {
        $data['categories'] =  Category::select('id','title')->orderBy('title','asc')->get();
        return view('gallery.create',$data);
    }
   

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|nullable',
            'category' => 'present|nullable',
            'gallery.*' => 'required|file|max:500000|mimes:jpeg,png,jpg,gif,svg',
            'location' => 'present|nullable',
            'description' => 'present|nullable',
        ]);

        
        $images = $request->gallery;
        $categories = request()->category;
        // dd($categories);
        
        $request = $request->all();
        $request['user_id'] = auth()->id();
        unset($request['gallery']);
        unset($request['category']);

        $new_gallery = Gallery::create($request);

        if( sizeof($categories) > 0 && $categories[0]!=null  ){
            foreach ($categories as $category) {
                GalleryCategory::create([
                                        'gallery_id' => $new_gallery->id
                                        ,'category_id' => $category
                                    ]);
            }
        }
        
        $image_attributes['gallery_id'] = $new_gallery->id;
        
        if(request()->file('gallery')){

            foreach (request()->gallery as $image) {
                //store the images
                $file_name = date('Y-m-d_H-i-s')."_".str_replace(" ","-",$image->getClientOriginalName());

                $extension = $image->getClientOriginalExtension();
                Storage::disk('public')->put( $file_name,  File::get($image));

                //and add these attributes to the databse for future retrevial of image
                $image_attributes['mime'] = $image->getClientMimeType();
                $image_attributes['original_file_name'] = $image->getClientOriginalName();
                $image_attributes['file_name'] = $file_name;
                
                Photo::create($image_attributes);
            }
        }
        
        
        History::create([
                            'gallery_id' => $new_gallery->id
                            ,'user_id' => auth()->user()->id
                            ,'action' => "Gallery Uploaded"
                        ]);


        return Redirect::to('photos')
       ->with('success','Greate! Gallery created successfully.');
    }
    

    public function show($id)
    {
        $where = array('id' => $id);
        $data['gallery'] = Gallery::where($where)->first();
 
        return view('gallery.show', $data);
    }

        // foreach ($gallery->photos as $photo) {
        //    Response::download(public_path()."/uploads/".$photo->file_name);
        // }

    public function download($id)
    {

       
        $where = array('id' => $id);
        $gallery = Gallery::where($where)->first();
        
        if(  sizeof(Gallery::where($where)->has('photos', '>' , 0)->get()) == 0 ){
            return Redirect::to('photos')->with('success','Cannot download photos as the gallery is empty!');
        }

        History::create([
                            'gallery_id' => $id
                            ,'user_id' => auth()->user()->id
                            ,'action' => "Gallery Downloaded"
                        ]);


        $zip_file = date('Y-m-d_H-i-s')."_".str_replace(" ","-",$gallery->name).'_'.$gallery->id.'.zip';
        $zip = new \ZipArchive();
        $zip->open($zip_file, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);

        $path = public_path('uploads');
        foreach ($gallery->photos as $photo) {
            $filePath = public_path('uploads').'/'.$photo->file_name;

            $relativePath = 'uploads/' . substr($filePath, strlen($path) + 1);
            $zip->addFile($filePath, $relativePath);            
        }

        $zip->renameName($zip_file,"test");

        $zip->close();
        return response()->download($zip_file);
    }
    

    public function edit($id)
    {   
        Session::put('gallery_edit_request_referrer', URL::previous());

        $where = array('id' => $id);
        $data['gallery'] = Gallery::where($where)->first();
        $data['categories'] =  Category::select('id','title')->orderBy('title','asc')->get();
 
        return view('gallery.edit', $data);
    }
   

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'present|nullable',
            'category' => 'present|nullable',
            'photo_override' => 'required',
            'gallery.*' => 'present|file|max:500000|mimes:jpeg,png,jpg,gif,svg',
            'location' => 'present|nullable',
            'description' => 'present|nullable',
        ]);

        
        $images = $request->gallery;
        $categories = request()->category;
        $photo_override = request()->photo_override;


        $request = $request->all();
        $request['user_id'] = auth()->id();
        unset($request['gallery']);
        unset($request['category']);
        unset($request['photo_override']);
        unset($request['_token']);
        unset($request['_method']);
        
        // dd($request['name']);
        
        if($request['name'] == null || $request['name'] == ""){
            unset($request['name']);
        }


        $gallery = Gallery::where('id',$id);

        if(  sizeof($categories) > 0 && $categories[0]!=null   ){

            GalleryCategory::where('gallery_id',$id)->delete();

            foreach ($categories as $category) {
                GalleryCategory::create([
                                        'gallery_id' => $id
                                        ,'category_id' => $category
                                    ]);
            }
        }
        
        $image_attributes['gallery_id'] = $id;


        
        if(request()->file('gallery')){
            $list_of_files = scandir(public_path()."/uploads/");
            
            if( $photo_override == 1 ){

                foreach ($gallery->get()->first()->photos as $photo) {
                    $previous_photo_path = public_path().'/uploads/'.$photo->file_name;
                    if (file_exists($previous_photo_path)) {
                        unlink($previous_photo_path);
                    }
                }
                
                Photo::where('gallery_id',$id)->delete();
            }

            foreach (request()->gallery as $image) {
                //store the images
                $file_name = date('Y-m-d_H-i-s')."_".str_replace(" ","-",$image->getClientOriginalName());

                $extension = $image->getClientOriginalExtension();
                Storage::disk('public')->put( $file_name,  File::get($image));

                //and add these attributes to the databse for future retrevial of image
                $image_attributes['mime'] = $image->getClientMimeType();
                $image_attributes['original_file_name'] = $image->getClientOriginalName();
                $image_attributes['file_name'] = $file_name;
                
                Photo::create($image_attributes);
            }
        }

        $gallery->update($request);
        
        History::create([
                            'gallery_id' => $id
                            ,'user_id' => auth()->user()->id
                            ,'action' => "Gallery Edited"
                        ]);
                        

        return redirect(Session::get('gallery_edit_request_referrer'))
       ->with('success','Great! Gallery updated successfully');
    }



    public function destroy($id)
    {
        $gallery = Gallery::where('id',$id);
        $list_of_files = scandir(public_path()."/uploads/");
        
        foreach ($gallery->get()->first()->photos as $photo) {
            
            $previous_photo_path = public_path().'/uploads/'.$photo->file_name;
            if (file_exists($previous_photo_path)) {
                unlink($previous_photo_path);
            }
        }

        $gallery->delete();
        Photo::where('gallery_id',$id)->delete();
        GalleryCategory::where('gallery_id',$id)->delete();
        
        History::create([
                            'gallery_id' => $id
                            ,'user_id' => auth()->user()->id
                            ,'action' => "Gallery Deleted"
                        ]);
    
        return Redirect::to('photos')->with('success','Gallery deleted successfully');
    }

    public function destroy_photo($id)
    {
        $photo = Photo::where('id',$id);
        $gallery_id = $photo->get()->first()->gallery_id;
        $gallery = Gallery::where('id',$gallery_id);
        $list_of_files = scandir(public_path()."/uploads/");
        
        if(sizeof($gallery->get()[0]->photos) <= 1){
          $gallery->delete();  
          
            $previous_photo_path = public_path().'/uploads/'.$photo->get()->first()->file_name;
            if (file_exists($previous_photo_path)) {
                unlink($previous_photo_path);
            }
            
            $photo->delete();
            
            return Redirect::to('photos')->with('success','Last photo & gallery deleted successfully');
        }
        
        $previous_photo_path = public_path().'/uploads/'.$photo->get()->first()->file_name;
        if (file_exists($previous_photo_path)) {
            unlink($previous_photo_path);
        }
        
        $photo->delete();
        
        History::create([
                            'gallery_id' => $gallery->get()->first()->id
                            ,'user_id' => auth()->user()->id
                            ,'action' => "Gallery Edited (Photo delete)"
                        ]);
        
        

       return redirect(Session::get('gallery_edit_request_referrer'))->with('success','Gallery deleted successfully');
    }


    public function search(){
        
   
        if(request()->sort == "new" || request()->sort == null){
            $galleries = Gallery::orderBy('id','desc');
        }else{
            $galleries = Gallery::orderBy('id','asc');
        }

        

        if(isset(request()->search)){
            // var_dump(request()->search);
            // var_dump($galleries->get()->all());
            $galleries->where(function($query){
                    $query->where('name', 'like', '%'.request()->search.'%')
                        ->orWhere('description', 'like', '%'.request()->search.'%')
                        ->orWhere('location', 'like', '%'.request()->search.'%')
                        ->orWhereHas('photos', function($query){ 
                            $query->where('original_file_name', 'like', '%'.request()->search.'%');
                        })
                        ->orWhereHas('user', function($query){ 
                            $query->where('name', 'like', '%'.request()->search.'%');
                        });
                   }) ;

            // var_dump($galleries->get()->all());
        }

        if(isset(request()->user)){
            
            $galleries->where(function($query){
                    $query
                        ->where('user_id', request()->user);
                    })
                    ;

        }

        if(isset(request()->from_date)){
            
            $galleries->where(function($query){
                    $query
                        ->where('created_at',">=", request()->from_date);
                    })
                    ;

        }

        if(isset(request()->category)){
            
            $galleries->where(function($query){
                    $query
                        ->whereHas('categories', function($query){ 
                            $query->where('category_id', request()->category);
                        });
                    })
                    ;
        }

        
        // $list_of_files = ;
        
        $galleries->whereHas('photos', function($query){ 
                            $query->whereIn('file_name', scandir(public_path()."/uploads/"));
                        });
        
        return $galleries;
    }
}

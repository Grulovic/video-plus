<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Redirect;

class CategoryController extends Controller
{
     public function __construct(){
        $this->middleware('auth');
    }
    
    public function index()
    {

        $data['categories'] = Category::orderBy('id','desc')->paginate(10);
        
        return view('category.list',$data);
    }
    

    public function create()
    {
        return view('category.create');
    }
   

    public function store(Request $request)
    {
        // var_dump($request->all());
        

        $request->validate([
            'title' => 'required',
            'description' => 'required'
        ]);
        
        $request = $request->all();
        unset($request['_token']);
        unset($request['_method']);
        $request['user_id'] = auth()->user()->id;
        

        Category::create($request);
    
        return Redirect::to('categories')
       ->with('success','Greate! Category created successfully.');
    }
    

    public function show($id)
    {

        $where = array('id' => $id);
        $data['category'] = Category::where($where)->first();

        if( auth()->user()->type != "admin" ){
            abort_unless( auth()->user()->id == $data['category']->user_id,403);         
        }
 
        return view('category.show', $data);
    }
    

    public function edit($id)
    {   
        $where = array('id' => $id);
        $data['category'] = Category::where($where)->first();
        
        if( auth()->user()->type != "admin" ){
            abort_unless( auth()->user()->id == $data['category']->user_id,403);
        }

        

        return view('category.edit', $data);
    }
   

    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'required'
        ]);
        
        $request = $request->all();
        unset($request['_token']);
        unset($request['_method']);
        // $update = ['title' => $request->title, 'description' => $request->description];
        $category = Category::where('id',$id);

        if( auth()->user()->type != "admin" ){
            abort_unless( auth()->user()->id == $category->first()->user_id,403);
        }
        


        $category->update($request);
    
        return Redirect::to('categories')
       ->with('success','Great! Category updated successfully');
    }
   

    public function destroy($id)
    {
        $category = Category::where('id',$id);

        if( auth()->user()->type != "admin" ){
            abort_unless( auth()->user()->id == $category->first()->user_id,403);
        }
        


        $category->delete();
   
        return Redirect::to('categories')->with('success','Category deleted successfully');
    }





}

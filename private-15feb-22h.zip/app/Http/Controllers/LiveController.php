  public function __construct(){
        $this->middleware('auth');
    }
    
    public function index()
    {

        $data['lives'] = Live::orderBy('id','desc')->paginate(10);
        
        return view('live.list',$data);
    }
    

    public function create()
    {
        return view('live.create');
    }
   

    public function store(Request $request)
    {
        // var_dump($request->all());
        

        $request->validate([
            'title' => 'required',
            'description' => 'required'
        ]);
        
        $request = $request->all();
        unset($request['_token']);
        unset($request['_method']);
        $request['user_id'] = auth()->user()->id;
        

        Live::create($request);
    
        return Redirect::to('lives')
       ->with('success','Greate! Live created successfully.');
    }
    

    public function show($id)
    {

        $where = array('id' => $id);
        $data['live'] = Live::where($where)->first();

        if( auth()->user()->type != "admin" ){
            abort_unless( auth()->user()->id == $data['live']->user_id,403);         
        }
 
        return view('live.show', $data);
    }
    

    public function edit($id)
    {   
        $where = array('id' => $id);
        $data['live'] = Live::where($where)->first();
        
        if( auth()->user()->type != "admin" ){
            abort_unless( auth()->user()->id == $data['live']->user_id,403);
        }

        

        return view('live.edit', $data);
    }
   

    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'required'
        ]);
        
        $request = $request->all();
        unset($request['_token']);
        unset($request['_method']);
        // $update = ['title' => $request->title, 'description' => $request->description];
        $live = Live::where('id',$id);

        if( auth()->user()->type != "admin" ){
            abort_unless( auth()->user()->id == $live->first()->user_id,403);
        }
        


        $live->update($request);
    
        return Redirect::to('lives')
       ->with('success','Great! Live updated successfully');
    }
   

    public function destroy($id)
    {
        $live = Live::where('id',$id);

        if( auth()->user()->type != "admin" ){
            abort_unless( auth()->user()->id == $live->first()->user_id,403);
        }
        


        $live->delete();
   
        return Redirect::to('lives')->with('success','Live deleted successfully');
    }
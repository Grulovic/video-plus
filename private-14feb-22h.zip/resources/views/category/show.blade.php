<x-app-layout>
    <x-slot name="header">
 
<div class="row m-0 p-0">
  <div class="col-6">
    <h2>Showing Category <strong>{{ $category->title }}</strong></h2>
  </div><div class="col-6 text-right">
    
    <a class="btn btn-danger mb-2" href="{{ URL::previous() }}"><i class="fas fa-caret-left"></i></a>
    <a href="{{ route('categories.index') }}" class="btn btn-danger mb-2 text-right">Go to categories</a> 
  </div>

</div>

</x-slot>
  



<div class="row m-0 p-0 pt-5 pb-5">
  <div class="col-md-2"></div>

  <div class="col-md-8">

    <div class="card">
      <div class="card-body">
        <small class="float-right">ID: {{ $category->id }}</small>
        <h3 class="card-title"><strong>Title:</strong> {{ $category->{'title'} }}</h3>
        

        <p><strong>User ID:</strong> {{ $category->user_id }}</p>
        <p><strong>User Name:</strong> {{ $category->user->name }}</p>
        <p><strong>Description:</strong> {{ $category->description }}</p>
        <p><strong>Created at:</strong> {{ $category->created_at }}</p>

       

      </div>

      <div class="card-footer text-center">
        
        <div class=" btn-group">
          <!-- <div><a href="{{ route('categories.show',$category->id)}}" class="btn btn-warning mr-3">Show <i class="far fa-eye"></i></a></div> -->
          <div><a href="{{ route('categories.edit',$category->id)}}" class="btn btn-primary mr-3"><i class="far fa-edit"></i> Edit </a></div>

          <div><form action="{{ route('categories.destroy', $category->id)}}" method="post">
          {{ csrf_field() }}
          @method('DELETE')
          <button class="btn btn-danger mr-3" category="submit"><i class="far fa-trash-alt"></i> Delete</button>
          </form></div>
        </div>

      </div>

    </div>

            
            
  

  </div>

  <div class="col-md-2"></div>


</div>
  


</x-app-layout>
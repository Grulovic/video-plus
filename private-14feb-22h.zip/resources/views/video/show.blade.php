<x-app-layout>
    <x-slot name="header">
 
      <div class="row m-0 p-0">
        <div class="col-6">
          <h4>Showing Video (ID: {{ $video->id }})</h4>
        </div><div class="col-6 text-right">
          
          <a class="btn btn-danger mb-2" href="{{ URL::previous() }}"><i class="fas fa-caret-left"></i></a>
          <a href="{{ route('videos.index') }}" class="btn btn-danger mb-2 text-right">Go to Videos</a> 
        </div>
      </div>

    </x-slot>


<style type="text/css">
  #vide-col .card-img-top{
    border-radius:0.25rem 0 0 0.25rem; 
  }

  #desc-card-col .card{
    border-radius:0 0.25rem 0.25rem 0;
  }

  @media only screen and (max-width: 991px) {
    #vide-col .card-img-top{
      border-radius:0.25rem 0.25rem 0 0; 
    }

    #desc-card-col .card{
      border-radius:0 0 0.25rem 0.25rem;
    }
  }
</style>



<div class="container">
<div class="row pt-5 pb-5 pl-1 pr-1">
  
<div id="vide-col" class="col-lg-7 d-flex align-items-stretch p-0 ">
  <video id="" class="card-img-top rounded-left shadow-sm bg-dark" style="min-height: 400px; width: 100%!important; display: block;" controls="true"  preload="metadata" playsinline >

      <source src="{{ url('uploads/'.$video->file_name) }}#t=0.1" type="{{$video->mime}}">
      Your browser does not support the video tag.
    </video>
</div>

<div id="desc-card-col" class="col-lg-5 d-flex align-items-stretch p-0 ">
  <div class="card w-100  shadow-sm" style="">
    

    <div class="card-body">
      <h2>{{$video->name}}</h2>
      <p class="text-muted">
        @if( sizeof($video->categories) > 0 )
          @foreach($video->categories as $category)
          {{$category->category->title}} 
            @if(!$loop->last) | @endif
          @endforeach
        @else
          Video categories not assigned.
        @endif
      </p>

      
      <p class="mb-0 pb-0"><strong>Video uploaded by:</strong> {{ $video->user->name}}</p>

      <p class="mb-0 pb-0"><strong>Location:</strong> {{ $video->location}}</p>
      <p class="mb-0 pb-0"><strong>Date of upload:</strong> {{ $video->created_at}}</p>
      <br>

      <strong>Description:</strong>
      <p class="mb-0 pb-0">{{ $video->description}}</p>
      <br>

      <p class="mb-0 pb-0"><strong>File type:</strong> {{ $video->mime}}</p>

      <p class="mb-0 pb-0"><strong>File size:</strong> {{ $video->size}}</p>
      <br>
      


    </div>
    
    <div class="card-footer text-right">
        <!-- <input type="text" value="{{ route('videos.show',$video->id)}}" id="current_video_url"> -->

        <div class="btn-group">
          <button class="btn btn btn-info" onclick="copyToClipboard('{{ route('videos.show',$video->id)}}')"><i class="far fa-share-square"></i> Copy Link</button>
          <!-- <a href="{{ route('videos.show',$video->id)}}" class="btn btn-sm btn-outline-primary"><i class="far fa-eye"></i> View</a> -->
          <a href="{{ route('videos.download',$video->id)}}" class="btn btn btn-success"><i class="fas fa-download"></i> Download</a>
          <a href="{{ route('videos.edit',$video->id)}}" class="btn btn btn-warning text-white"><i class="far fa-edit"></i> Edit</a>

          <form class="" action="{{ route('videos.destroy', $video->id)}}" method="post"
            >
            {{ csrf_field() }}
            @method('DELETE')
            <button  type="submit" class="btn btn btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
            data-toggle="tooltip" data-placement="top" title="Delete video">
            <!-- Delete --><i class="far fa-trash-alt"></i> Delete</button>
          </form>


          
        </div>
      </div>

  </div>
</div>


</div>
</div>




</x-app-layout>
<div class="col-lg-12 m-0 p-0">
  <div class="card shadow-sm mb-4">
    <div class="row no-gutters bg-dark">
        
        <div class="col-lg-5 h-100 bg-dark my-auto" style="">
          <video id="" class="card-img bg-dark" style="min-height:100%; width: 100%!important; display: block;" controls="true"  preload="metadata" playsinline muted>
            <!-- preload="none" -->
            <source src="{{ url('uploads/'.$video->file_name) }}#t=0.1" type="{{$video->mime}}">
            Your browser does not support the video tag.
          </video>
        </div>

        <div class="col-lg-7 bg-white">
          <div class="row m-0 p-0  h-100">
            <div class="col-12 pt-2 " >
              <div class="text-muted text-right w-100 pr-2"><small>{{ date('j. F Y. H:i', strtotime($video->created_at)) }}</small></div>
              <a href="{{ route('videos.show',$video->id)}}" class="text-black"><h2>{{$video->name}}</h2></a>
                <p class="text-muted">
                  @if( sizeof($video->categories) > 0 )
                    @foreach($video->categories as $category)
                    {{$category->category->title}} 
                      @if(!$loop->last) | @endif
                    @endforeach
                  @else
                    Video categories not assigned.
                  @endif
                </p>
            </div>
          

            <div class="col-lg-5">
                <p class="mb-0 pb-0"><strong>Video uploaded by:</strong> {{ $video->user->name}}</p>
                <p class="mb-0 pb-0"><strong>Location:</strong> {{ $video->location}}</p>
                <p class="mb-0 pb-0"><strong>Date of upload:</strong> {{ $video->created_at}}</p>
                <br>
                <p class="mb-0 pb-0"><strong>File type:</strong> {{ $video->mime}}</p>
                <p class="mb-0 pb-0"><strong>File size:</strong> {{ $video->size}}</p>
                <br>
            </div>

            <div class="col-lg-7" style="border-radius: 0px 0px 0.25rem  0px; ">
               <strong>Description:</strong>
                <p class="mb-0 pb-0">{{ $video->description}}</p>
                <br>
            </div>

             <div class="col-lg-12 card-footer text-center text-lg-right w-100 align-self-end pl-1 pr-3"  style="">
              <div class="btn-group">
                <a href="{{ route('videos.show',$video->id)}}" class="btn btn-sm  btn-primary"><i class="far fa-eye"></i> View</a>
                <button class="btn btn-sm btn-info" onclick="copyToClipboard('{{ route('videos.show',$video->id)}}')"><i class="far fa-share-square"></i> Copy link</button>
                
                <a href="{{ route('videos.download',$video->id)}}" class="btn btn-sm  btn-success"><i class="fas fa-download"></i> Download</a>
                <a href="{{ route('videos.edit',$video->id)}}" class="btn btn-sm  btn-warning"><i class="far fa-edit"></i> Edit</a>

                <form class="" action="{{ route('videos.destroy', $video->id)}}" method="post"
                  >
                  {{ csrf_field() }}
                  @method('DELETE')
                  <button  type="submit" class="btn btn-sm  btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
                  data-toggle="tooltip" data-placement="top" title="Delete video">
                  <i class="far fa-trash-alt"></i> Delete</button>
                </form>

              </div>
            </div>


          </div>
        </div>

    </div>
</div>
</div>
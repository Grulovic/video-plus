<?php return array (
  'navigation-simple' => 'App\\Http\\Livewire\\NavigationSimple',
);
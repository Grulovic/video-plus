<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Photo;
use App\Models\Gallery;
use App\Models\Video;
use App\Models\History;



class HomeController extends Controller
{
    public function index(){

    	$videos_carausel = Video::orderBy('id', 'desc')->take(3)->get();
    	$photos_carausel = Gallery::orderBy('id', 'desc')->take(3)->get();
    	$merged = $videos_carausel->merge($photos_carausel);
        $data['carausel'] = $merged->shuffle();

    	
        $data['latest_videos'] = Video::orderBy('id', 'desc')->take(4)->get();
        $data['latest_photos'] = Gallery::orderBy('id', 'desc')->take(4)->get();

        // dd($data['carausel']);

    	return view('home',$data);
    }
}
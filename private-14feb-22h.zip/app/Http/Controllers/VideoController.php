<?php

namespace App\Http\Controllers;

use App\Models\Video;
use App\Models\User;
use App\Models\Category;
use App\Models\VideoCategory;
use App\Models\History;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Response;
use Redirect;
use Session;
use URL;

class VideoController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
    
    public function index()
    {
        
        // dd(public_path());
        $data['videos'] = $this->search()->paginate(12);
        $data['users'] =  User::select('id','name')->orderBy('id','asc')->get();
        $data['categories'] =  Category::select('id','title')->orderBy('title','asc')->get();

        return view('video.grid',$data);
    }

    public function list()
    {
        $data['videos'] = $this->search()->paginate(12);
        $data['users'] =  User::select('id','name')->orderBy('id','asc')->get();
        $data['categories'] =  Category::select('id','title')->orderBy('title','asc')->get();

        return view('video.list',$data);
    }
    

    public function create()
    {
        $data['categories'] =  Category::select('id','title')->orderBy('title','asc')->get();
        return view('video.create',$data);
    }
   

    public function store(Request $request)
    {
                    // dd(request()->category);
        
        
        $request->validate([
            'name' => 'present|nullable',
            'category' => 'required|nullable',
            'video' => 'required|file|max:500000|mimetypes:video/x-ms-asf,video/x-flv,video/mp4,application/x-mpegURL,video/MP2T,video/3gpp,video/quicktime,video/x-msvideo,video/x-ms-wmv,video/avi,avi,flv,mp4,mpeg',
            'location' => 'present|nullable',
            'description' => 'present|nullable',
        ]);


        if( request()->file('video') ){
            
            
            $file = $request->file('video');
            
            

            //  if( $user_details_object->file_name != null){
            //     $image_path = public_path().'/uploads/'.$user_details_object->file_name;
            //     unlink($image_path);
            // }

            $video = request()->video;
            
            if( request()->name == null ){
                  $request['name'] = $video->getClientOriginalName();
            }
            
            $file_name = date('Y-m-d_H-i-s')."_".str_replace(" ","-",$video->getClientOriginalName());

            Storage::disk('public')->put($file_name,  File::get($video));
            
            // $file->storeAs(public_path('vid'), $file_name);

            $request = $request->all();
            $request['user_id'] = auth()->user()->id;
            $request['mime'] = $video->getClientMimeType();
            
            $size = $video->getSize();
            $precision = 2;
            $base = log($size, 1024);
            $suffixes = array('', 'KB', 'MB', 'GB', 'TB');   
            $size= round(pow(1024, $base - floor($base)), $precision) .' '. $suffixes[floor($base)];
            $request['size'] = $size;

            $request['original_file_name'] = $video->getClientOriginalName();
            $request['file_name'] = $file_name;
            $request['runtime'] = 123.456;


            unset($request['file']);

            $new_video = Video::create($request);

        }
        
        if( sizeof(request()->category) >0 ){

            $categories = request()->category;

            foreach ($categories as $category) {
                if($category!=null){
                    VideoCategory::create([
                                            'video_id' => $new_video->id
                                            ,'category_id' => $category
                                        ]);
                }
            }
        }

        return Redirect::to('videos')
       ->with('success','Greate! Video created successfully.');
    }
    

    public function show($id)
    {
        $where = array('id' => $id);
        $data['video'] = Video::where($where)->first();
 
        return view('video.show', $data);
    }

    public function download($id)
    {
        $where = array('id' => $id);
        $video = Video::where($where)->first();

        History::create([
                            'video_id' => $id
                            ,'user_id' => auth()->user()->id
                            ,'action' => "Video Downloaded"
                        ]);

        return Response::download(public_path()."/uploads/".$video->file_name);
    }
    

    public function edit($id)
    {   
        Session::put('video_edit_request_referrer', URL::previous());

        $where = array('id' => $id);
        $data['video'] = Video::where($where)->first();
        $data['categories'] =  Category::select('id','title')->orderBy('title','asc')->get();
 
        return view('video.edit', $data);
    }
   

    public function update(Request $request, $id)
    {
        
        
    
       $request->validate([
            'name' => 'present|nullable',
            'category' => 'required|nullable',
            'video' => 'nullable|file|max:500000|mimetypes:video/x-ms-asf,video/x-flv,video/mp4,application/x-mpegURL,video/MP2T,video/3gpp,video/quicktime,video/x-msvideo,video/x-ms-wmv,video/avi,avi,flv,mp4,mpeg',
            'location' => 'present|nullable',
            'description' => 'present|nullable',
        ]);


        if( request()->file('video') ){

            $file = $request->file('video');

            //  if( $user_details_object->file_name != null){
            //     $image_path = public_path().'/uploads/'.$user_details_object->file_name;
            //     unlink($image_path);
            // }

            $video = request()->video;
            $extension = $video->getClientOriginalExtension();
            $file_name = date('Y-m-d_H-i-s')."_".str_replace(" ","-",$video->getClientOriginalName());

            Storage::disk('public')->put($file_name,  File::get($video));
            
            // $file->storeAs(public_path('vid'), $file_name);

            $request = $request->all();
            $request['mime'] = $video->getClientMimeType();

            $size = $video->getSize();
            $precision = 2;
            $base = log($size, 1024);
            $suffixes = array('', 'kb', 'mb', 'gb', 'tb');   
            $size= round(pow(1024, $base - floor($base)), $precision) .' '. $suffixes[floor($base)];

            $request['size'] = $size;


            $request['original_file_name'] = $video->getClientOriginalName();
            $request['file_name'] = $file_name;
            $request['runtime'] = 123.456;


            unset($request['file']);
            unset($request['video']);
            unset($request['_token']);
            unset($request['_method']);
            unset($request['user_id']);
            
            $video = Video::where('id',$id);

            $previous_video_path = public_path().'/uploads/'.$video->latest()->first()->file_name;
            unlink($previous_video_path);

        }else{

            $video = Video::where('id',$id);
            
            $request = $request->all();

            unset($request['file']);
            unset($request['video']);
            unset($request['_token']);
            unset($request['_method']);
            unset($request['user_id']);
        }

        if( sizeof(request()->category) > 1 ){
            $categories = request()->category;

             VideoCategory::where('video_id',$id)->delete();

            foreach ($categories as $category) {
                if($category!=null){
                VideoCategory::create([
                                        'video_id' => $id
                                        ,'category_id' => $category
                                    ]);
                }
            }

            unset($request['category']);

        }else{
             VideoCategory::where('video_id',$id)->delete();
             unset($request['category']);
        }



        $video->update($request);
   
        // return Redirect::to('videos')
    return redirect(Session::get('video_edit_request_referrer'))
       ->with('success','Great! Video updated successfully');
    }



    public function destroy($id)
    {
        $video = Video::where('id',$id);
        
        $previous_video_path = public_path().'/uploads/'.$video->latest()->first()->file_name;
        unlink($previous_video_path);
        

        $video->delete();
        VideoCategory::where('video_id',$id)->delete();
   
        return Redirect::to('videos')->with('success','Video deleted successfully');
    }


    public function search(){
        
   
        if(request()->sort == "new" || request()->sort == null){
            $videos = Video::orderBy('id','desc');
        }else{
            $videos = Video::orderBy('id','asc');
        }

        

        if(isset(request()->search)){
            // var_dump(request()->search);
            // var_dump($videos->get()->all());
            $videos->where(function($query){
                    $query->where('name', 'like', '%'.request()->search.'%')
                        ->orWhere('description', 'like', '%'.request()->search.'%')
                        ->orWhere('location', 'like', '%'.request()->search.'%')
                        ->orWhere('original_file_name', 'like', '%'.request()->search.'%')
                        ->orWhereHas('user', function($query){ 
                            $query->where('name', 'like', '%'.request()->search.'%');
                        });
                   }) ;

            // var_dump($videos->get()->all());
        }

        if(isset(request()->user)){
            
            $videos->where(function($query){
                    $query
                        ->where('user_id', request()->user);
                    })
                    ;

        }

        if(isset(request()->from_date)){
            
            $videos->where(function($query){
                    $query
                        ->where('created_at',">=", request()->from_date);
                    })
                    ;

        }

        if(isset(request()->category)){
            
            $videos->where(function($query){
                    $query
                        ->whereHas('categories', function($query){ 
                            $query->where('category_id', request()->category);
                        });
                    })
                    ;
        }

        
        
        return $videos;
    }


}

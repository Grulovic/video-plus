

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
   

 <div class="row  m-0 p-0">
  
  <div class="col-lg-3  text-left">
    <h2>Category List:</h2>
  </div>



  <div class="col-lg-9 text-center">

    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success float-right ml-1 "><i class="fas fa-archive"></i> Add Category</a> 

  </div>

  
</div>


     <?php $__env->endSlot(); ?>

 <div class="row m-0 p-0 pt-5 pb-5">
      <div class="col-md-1"></div>

      <div class="col-md-10 p-0" style="padding-right: 0; overflow-x: auto;">          
        <table class="table table-bordered sortable" id="laravel_crud">
         <thead>
            <tr class="thead-dark">
               <th colspan="3" class="text-center">Action</th>

                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>User ID</th>
                <th>User Name</th>
                <th>Created at</th>
            </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class=" bg-white " >
              
              <td class="text-center  bg-dark text-white" style="border-color:#454d55;">
                <a href="<?php echo e(route('categories.show',$category->id)); ?>" class="btn btn-warning"><!-- Show --> <i class="far fa-eye"></i></a>
              </td>
               <td class="text-center  bg-dark text-white" style="border-color:#454d55;">
                <a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-primary"><!-- Edit --> <i class="far fa-edit"></i></a></td>
               <td class="text-center  bg-dark text-white" style="border-color:#454d55;">
               <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger" category="submit"><!-- Delete --><i class="far fa-trash-alt"></i></button>
              </form>
              </td>

               <td class="text-center  bg-dark text-white" style="border-color:#454d55;"><?php echo e($category->id); ?></td>
              

              <td><?php echo e($category->title); ?></td>
              <td><?php echo e($category->description); ?></td>                
              <tD><?php echo e($category->user->id); ?></td>
              <td><?php echo e($category->user->name); ?></tD>
              <td><?php echo e($category->created_at); ?></td>
              


              

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
            <?php if(count($categories) < 1): ?>
              <tr class="bg-white">
               <td colspan="13" class="text-center">There are no category available yet!</td>
              </td>
            </tr>
            <?php endif; ?>
         </tbody>
        </table>
        <?php echo $categories->appends(request()->input())->links(); ?>

     </div> 
      <div class="col-md-1"></div>


     


 </div>




  <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/grulovic/video_gov/resources/views/category/list.blade.php ENDPATH**/ ?>
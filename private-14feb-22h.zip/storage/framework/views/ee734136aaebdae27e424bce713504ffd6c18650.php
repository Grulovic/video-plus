<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
 
      <div class="row m-0 p-0">
        <div class="col-10">
          <h4>Showing Gallery <strong><?php echo e($gallery->name); ?></strong> </h4>
        </div><div class="col-2 text-right">
          
          <a class="btn btn-danger mb-2" href="<?php echo e(URL::previous()); ?>"><i class="fas fa-caret-left"></i></a>
          <a href="<?php echo e(route('photos.index')); ?>" class="btn btn-danger mb-2 text-right">Go to Videos</a> 
        </div>
      </div>

     <?php $__env->endSlot(); ?>


<style type="text/css">
  #vide-col .card-img-top{
    border-radius:0.25rem 0 0 0.25rem; 
  }

  #desc-card-col .card{
    border-radius:0 0.25rem 0.25rem 0;
  }

  @media  only screen and (max-width: 991px) {
    #vide-col .card-img-top{
      border-radius:0.25rem 0.25rem 0 0; 
    }

    #desc-card-col .card{
      border-radius:0 0 0.25rem 0.25rem;
    }
  }


</style>



<div class="container">
<div class="row pt-5 pb-5 pl-1 pr-1">
  
<div id="vide-col" class="col-lg-7 d-flex align-items-stretch p-0 ">


  <div id="gallery<?php echo e($gallery->id); ?>" class="carousel slide card-img-top rounded-left shadow-sm bg-dark" data-ride="carousel" style="max-height: 100%; width: 100%!important; display: block;">
    <ol class="carousel-indicators">
      <?php $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li data-target="#gallery<?php echo e($gallery->id); ?>" data-slide-to="<?php echo e($loop->index); ?>" <?php echo e($loop->first ? 'class="active"':''); ?>></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
    <div class="carousel-inner  rounded-left text-center h-100  my-auto" style="min-height: 400px;">

      <?php $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item <?php echo e($loop->first ? 'active':''); ?> h-100 rounded-left text-center h-100 my-auto" 
        style="background-image:url(<?php echo e(url('uploads/'.$photo->file_name)); ?>); background-size:contain; background-position: center; background-repeat:no-repeat; ">
        <div>
        <p class="mb-0 w-100 text-white bg-info text-center"style="position:absolute;bottom:0px;"><?php echo e($photo->file_name); ?></p>
        <img src="<?php echo e(url('uploads/'.$photo->file_name)); ?>" class="d-none text-center" style="max-height: 500px; width:auto;  margin-left: auto; margin-right: auto;">
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      

    </div>
    <a class="carousel-control-prev " href="#gallery<?php echo e($gallery->id); ?>" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next text-shadow-sm" href="#gallery<?php echo e($gallery->id); ?>" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


</div>

<div id="desc-card-col" class="col-lg-5 d-flex align-items-stretch p-0 ">
  <div class="card w-100  shadow-sm" style="">
    

    <div class="card-body">
      <h2><?php echo e($gallery->name); ?></h2>
      <p class="text-muted">
        <?php if( sizeof($gallery->categories) > 0 ): ?>
          <?php $__currentLoopData = $gallery->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($category->category->title); ?> 
            <?php if(!$loop->last): ?> | <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          Video categories not assigned.
        <?php endif; ?>
      </p>
               <p class="text-muted mb-0 pb-0"># of photos: <?php echo e(sizeof($gallery->photos)); ?></p>

      
      <p class="mb-0 pb-0"><strong>Video uploaded by:</strong> <?php echo e($gallery->user->name); ?></p>

      <p class="mb-0 pb-0"><strong>Location:</strong> <?php echo e($gallery->location); ?></p>
      <p class="mb-0 pb-0"><strong>Date of upload:</strong> <?php echo e($gallery->created_at); ?></p>
      <br><strong>Description:</strong>
      <p class="mb-0 pb-0"><?php echo e($gallery->description); ?></p>
      <br>
                      <strong>List of Photos:</strong>
                <div id="upload_images" class="card" style="max-height: 242px; overflow-y: scroll;">

                <?php $__currentLoopData = $gallery->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="upload_image card m-2 p-1 bg-light"><div class="text-left"><i class="fas fa-file-image float-left mt-1 mr-2"></i><?php echo e($photo->original_file_name); ?></div></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

    
      <br>


    </div>
    
    <div class="card-footer text-right">
        <!-- <input type="text" value="<?php echo e(route('photos.show',$gallery->id)); ?>" id="current_gallery_url"> -->

        <div class="btn-group">
          <button class="btn btn btn-info" onclick="copyToClipboard('<?php echo e(route('photos.show',$gallery->id)); ?>')"><i class="far fa-share-square"></i> Copy Link</button>
          <!-- <a href="<?php echo e(route('photos.show',$gallery->id)); ?>" class="btn btn-sm btn-outline-primary"><i class="far fa-eye"></i> View</a> -->
          <a href="<?php echo e(route('photos.download',$gallery->id)); ?>" class="btn btn btn-success"><i class="fas fa-download"></i> Download</a>
          <a href="<?php echo e(route('photos.edit',$gallery->id)); ?>" class="btn btn btn-warning text-white"><i class="far fa-edit"></i> Edit</a>

          <form class="" action="<?php echo e(route('photos.destroy', $gallery->id)); ?>" method="post"
            >
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('DELETE'); ?>
            <button  type="submit" class="btn btn btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
            data-toggle="tooltip" data-placement="top" title="Delete gallery">
            <!-- Delete --><i class="far fa-trash-alt"></i> Delete</button>
          </form>


          
        </div>
      </div>

  </div>
</div>


</div>
</div>




 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Users/grulovic/code/video-gov/resources/views/gallery/show.blade.php ENDPATH**/ ?>
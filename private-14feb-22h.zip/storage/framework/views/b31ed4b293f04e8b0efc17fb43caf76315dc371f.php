<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
 
      <div class="row m-0 p-0">
        <div class="col-6">
          <h4>Showing Video (ID: <?php echo e($video->id); ?>)</h4>
        </div><div class="col-6 text-right">
          
          <a class="btn btn-danger mb-2" href="<?php echo e(URL::previous()); ?>"><i class="fas fa-caret-left"></i></a>
          <a href="<?php echo e(route('videos.index')); ?>" class="btn btn-danger mb-2 text-right">Go to Videos</a> 
        </div>
      </div>

     <?php $__env->endSlot(); ?>


<style type="text/css">
  #vide-col .card-img-top{
    border-radius:0.25rem 0 0 0.25rem; 
  }

  #desc-card-col .card{
    border-radius:0 0.25rem 0.25rem 0;
  }

  @media  only screen and (max-width: 991px) {
    #vide-col .card-img-top{
      border-radius:0.25rem 0.25rem 0 0; 
    }

    #desc-card-col .card{
      border-radius:0 0 0.25rem 0.25rem;
    }
  }
</style>



<div class="container">
<div class="row pt-5 pb-5 pl-1 pr-1">
  
<div id="vide-col" class="col-lg-7 d-flex align-items-stretch p-0 ">
  <video id="" class="card-img-top rounded-left shadow-sm bg-dark" style="min-height: 400px; width: 100%!important; display: block;" controls="true"  preload="metadata" playsinline >

      <source src="<?php echo e(url('uploads/'.$video->file_name)); ?>#t=0.1" type="<?php echo e($video->mime); ?>">
      Your browser does not support the video tag.
    </video>
</div>

<div id="desc-card-col" class="col-lg-5 d-flex align-items-stretch p-0 ">
  <div class="card w-100  shadow-sm" style="">
    

    <div class="card-body">
      <h2><?php echo e($video->name); ?></h2>
      <p class="text-muted">
        <?php if( sizeof($video->categories) > 0 ): ?>
          <?php $__currentLoopData = $video->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($category->category->title); ?> 
            <?php if(!$loop->last): ?> | <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          Video categories not assigned.
        <?php endif; ?>
      </p>

      
      <p class="mb-0 pb-0"><strong>Video uploaded by:</strong> <?php echo e($video->user->name); ?></p>

      <p class="mb-0 pb-0"><strong>Location:</strong> <?php echo e($video->location); ?></p>
      <p class="mb-0 pb-0"><strong>Date of upload:</strong> <?php echo e($video->created_at); ?></p>
      <br>

      <strong>Description:</strong>
      <p class="mb-0 pb-0"><?php echo e($video->description); ?></p>
      <br>

      <p class="mb-0 pb-0"><strong>File type:</strong> <?php echo e($video->mime); ?></p>

      <p class="mb-0 pb-0"><strong>File size:</strong> <?php echo e($video->size); ?></p>
      <br>
      


    </div>
    
    <div class="card-footer text-right">
        <!-- <input type="text" value="<?php echo e(route('videos.show',$video->id)); ?>" id="current_video_url"> -->

        <div class="btn-group">
          <button class="btn btn btn-info" onclick="copyToClipboard('<?php echo e(route('videos.show',$video->id)); ?>')"><i class="far fa-share-square"></i> Copy Link</button>
          <!-- <a href="<?php echo e(route('videos.show',$video->id)); ?>" class="btn btn-sm btn-outline-primary"><i class="far fa-eye"></i> View</a> -->
          <a href="<?php echo e(route('videos.download',$video->id)); ?>" class="btn btn btn-success"><i class="fas fa-download"></i> Download</a>
          <a href="<?php echo e(route('videos.edit',$video->id)); ?>" class="btn btn btn-warning text-white"><i class="far fa-edit"></i> Edit</a>

          <form class="" action="<?php echo e(route('videos.destroy', $video->id)); ?>" method="post"
            >
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('DELETE'); ?>
            <button  type="submit" class="btn btn btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
            data-toggle="tooltip" data-placement="top" title="Delete video">
            <!-- Delete --><i class="far fa-trash-alt"></i> Delete</button>
          </form>


          
        </div>
      </div>

  </div>
</div>


</div>
</div>




 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/grulovic/video_gov/resources/views/video/show.blade.php ENDPATH**/ ?>
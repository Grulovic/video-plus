<a href="/">
    <img src="<?php echo e(asset('video-gov-logo.png')); ?>" style="max-height: 100px; ">
</a>
<?php /**PATH /home/grulovic/video_gov/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>
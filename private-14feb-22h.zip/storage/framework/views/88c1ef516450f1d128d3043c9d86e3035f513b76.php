<?php if (isset($component)) { $__componentOriginal501e81491cdd9b61e2d9ba717a17361860b8d597 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HomeLayout::class, []); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<?php echo $__env->make('home.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Latest Videos:</h2>
				<p>These are the latest videos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="<?php echo e(route('videos.index')); ?>">Show latest videos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			<?php $__currentLoopData = $latest_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $__env->make('home.video_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>


<hr>


	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Latest Photos:</h2>
				<p>These are the latest photos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="<?php echo e(route('photos.index')); ?>">Show latest photos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			<?php $__currentLoopData = $latest_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $__env->make('home.photo_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
  
  <hr>
  	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Videos from Category 1:</h2>
				<p>These are the latest videos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="<?php echo e(route('videos.index')); ?>">Show Category 1 videos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			<?php $__currentLoopData = $latest_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $__env->make('home.video_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>


<hr>
	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Photos from Category 1:</h2>
				<p>These are the latest photos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="<?php echo e(route('photos.index')); ?>">Show Category 1 photos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			<?php $__currentLoopData = $latest_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $__env->make('home.photo_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
  
  <hr>


  	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Most Downloaded Videos:</h2>
				<p>These are the latest videos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="<?php echo e(route('videos.index')); ?>">Show latest videos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			<?php $__currentLoopData = $latest_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $__env->make('home.video_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>


<hr>

	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Most Downloaded Photos:</h2>
				<p>These are the latest photos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="<?php echo e(route('photos.index')); ?>">Show latest photos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			<?php $__currentLoopData = $latest_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $__env->make('home.photo_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
  
  <hr>


 <?php if (isset($__componentOriginal501e81491cdd9b61e2d9ba717a17361860b8d597)): ?>
<?php $component = $__componentOriginal501e81491cdd9b61e2d9ba717a17361860b8d597; ?>
<?php unset($__componentOriginal501e81491cdd9b61e2d9ba717a17361860b8d597); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Users/grulovic/code/video-gov/resources/views/home.blade.php ENDPATH**/ ?>
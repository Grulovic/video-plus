<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 


<div class="row m-0 p-0">
  <div class="col-6 text-left">
        <h4>Add Video</h4>
    </div>
  <div class="col-6 text-right">
        <a href="<?php echo e(route('videos.index')); ?>" class="btn btn-danger mb-2">Go Back</a> 
    </div>
    
</div>

 <?php $__env->endSlot(); ?>


<script type="text/javascript">
$( document ).ready(function() {

   $(document).on("change", "#video", function(evt) {
      var $source = $('#video_preview');
      $source[0].src = URL.createObjectURL(this.files[0]);
      $source.parent()[0].load();
    });

   $(".custom-file-input").on("change", function() {
      var fileName = $(this).val().split("\\").pop();
      
      if(fileName.length > 50){
            var length = 50;
            var fileName = fileName.substring(0, length) + "...";
        }
      $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    });
    
    
    
    
    var chunk_size = 1024 * 1024; // 1mb
var reader = new FileReader();
 
jQuery('#my-form').submit(function(e) {
  // we handle the form submission ourself
  e.preventDefault();
 
  // acquire File object from file input field
  fileInput = document
    .getElementById('video')
    .files[0];
 
  // begin upload process
  uploadFile(fileInput);
});
 
function uploadFile(fileInput) {
  _uploadChunk(fileInput, 0, chunk_size);  
}
 
function _uploadChunk(file, offset, range) {
  // if no more chunks, send EOF
  if(offset >= file.size) {
    jQuery.post('http://video.grulovic.rs/videos', {
      filename: file.name,
      eof: true
    });
    return;
  }
 
  // prepare reader with an event listener
  reader.addEventListener('load', function(e) {
    var filename = file.name;
    var index = offset / chunk_size;
    var data = e.target.result.split(';base64,')[1];
 
    // build payload with indexed chunk to be sent
    var payload = {
      filename: filename,
      index: index,
      data: data,
    };
 
    // send payload, and buffer next chunk to be uploaded
    jQuery.post('http://video.grulovic.rs/videos',
      payload,
      function() {
        _uploadChunk(file, offset + range, chunk_size);
      }
    );
  }, {once: true} );
 
  // chunk and read file data
  var chunk = file.slice(offset, offset + range);
  reader.readAsDataURL(chunk);
}



   
});
</script>

<div class="row m-0 p-0 pt-5 pb-5">
<div class="col-md-2"></div>
<div class="col-md-8">
<form class="row" action="<?php echo e(route('videos.store')); ?>" method="POST" name="add_video" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>



  <div class="form-group col-lg-6">
        <strong>Name</strong>
        <input type="text" name="name" class="form-control" placeholder="Enter name of the video..." value="<?php echo e(old('name')); ?>">
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
    </div>

    <div class="form-group col-lg-6">
        <strong>Location</strong>
        <input type="text" name="location" class="form-control" placeholder="Enter the location..." value="<?php echo e(old('location')); ?>">
        <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
    </div>

     <div class="form-group col-lg-6 mb-3">
      <strong>Video File</strong>
      <div class="custom-file mb-4">
        <input type="file" name="video" id="video" class="custom-file-input">
        <label class="custom-file-label" for="video">Select video file...</label>
      </div>
      <span class="text-danger"><?php echo e($errors->first('video')); ?></span>

      <video controls class="w-100" style="height: 250px;  width: 100%!important; display: block;">
          <source src="mov_bbb.mp4" id="video_preview">
            Your browser does not support HTML5 video.
        </video>

    </div>

    

    <div class="col-lg-6">
                   <strong>Categories</strong>
      <div class="input-group  mb-2">

            <select multiple="" class="custom-select" id="category" name="category[]" required>
              <option value="" selected="">None</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

    
    <div class="form-group mb-3">
        <strong>Description</strong>
        <textarea class="form-control" col="4" name="description" placeholder="Enter video description..." style="min-height:175px;"><?php echo e(old('description')); ?></textarea>
        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
    </div>
</div>

    <div class="col-6 mt-3">
        <button type="submit" class="btn btn-primary w-100"><i class="fas fa-upload"></i> Upload video</button>
    </div>
    <div class="col-6 mt-3">
        <a href="<?php echo e(route('videos.index')); ?>" class="btn btn-danger w-100"><i class="fas fa-ban"></i> Cancel upload</a> 
    </div>
    


</form>

</div>
<div class="col-md-2"></div>
</div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/grulovic/video_gov/resources/views/video/create.blade.php ENDPATH**/ ?>
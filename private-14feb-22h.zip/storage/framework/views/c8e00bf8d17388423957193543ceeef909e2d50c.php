<div class="col-lg-12 m-0 p-0">
  <div class="card shadow-sm mb-4">
    <div class="row no-gutters bg-dark" style="max-height: 400px;">
        
        <div class="col-lg-5 h-100 my-auto border-right" style="
        ">
        <a href="<?php echo e(route('photos.show',$gallery->id)); ?>"><img src="<?php echo e(url('uploads/'.$gallery->photos[0]->file_name)); ?>" class="" style="max-height:400px; width: 100%!important; display: block; object-fit:cover;"></a>

           
  



        </div>

        <div class="col-lg-7 bg-white">
          <div class="row m-0 p-0  h-100">
            <div class="col-12 pt-2 " >
              <div class="text-muted text-right w-100 pr-2"><?php echo e(date('j. F Y. H:i', strtotime($gallery->created_at))); ?></div>
              <a href="<?php echo e(route('photos.show',$gallery->id)); ?>" class="text-black"><h2><?php echo e($gallery->name); ?></h2></a>

                <p class="text-muted">
                  <?php if( sizeof($gallery->categories) > 0 ): ?>
                    <?php $__currentLoopData = $gallery->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($category->category->title); ?> 
                      <?php if(!$loop->last): ?> | <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    Video categories not assigned.
                  <?php endif; ?>
                </p>
            </div>
          

            <div class="col-lg-5">
                <p class="mb-0 pb-0"><strong>Video uploaded by:</strong> <?php echo e($gallery->user->name); ?></p>
                <p class="mb-0 pb-0"><strong>Location:</strong> <?php echo e($gallery->location); ?></p>
                <p class="mb-0 pb-0"><strong>Date of upload:</strong> <?php echo e($gallery->created_at); ?></p>
                <br>


                <br>
            </div>

            <div class="col-lg-7" style="border-radius: 0px 0px 0.25rem  0px; ">
               <strong>Description:</strong>
                <p class="mb-0 pb-0"><?php echo e(Str::limit($gallery->description, 170, $end='...')); ?></p>
                <br>
            </div>

             <div class="col-lg-12 card-footer text-center text-lg-right w-100 align-self-end pl-1 pr-3"  style="">
              <div class="btn-group">
                <a href="<?php echo e(route('photos.show',$gallery->id)); ?>" class="btn btn-sm  btn-primary"><i class="far fa-eye"></i> View</a>
                <button class="btn btn-sm btn-info" onclick="copyToClipboard('<?php echo e(route('photos.show',$gallery->id)); ?>')"><i class="far fa-share-square"></i> Copy link</button>
                
                <a href="<?php echo e(route('photos.download',$gallery->id)); ?>" class="btn btn-sm  btn-success"><i class="fas fa-download"></i> Download</a>
                <a href="<?php echo e(route('photos.edit',$gallery->id)); ?>" class="btn btn-sm  btn-warning"><i class="far fa-edit"></i> Edit</a>

                <form class="" action="<?php echo e(route('photos.destroy', $gallery->id)); ?>" method="post"
                  >
                  <?php echo e(csrf_field()); ?>

                  <?php echo method_field('DELETE'); ?>
                  <button  type="submit" class="btn btn-sm  btn-danger" style="border-radius: 0 0.25rem 0.25rem 0;"
                  data-toggle="tooltip" data-placement="top" title="Delete gallery">
                  <i class="far fa-trash-alt"></i> Delete</button>
                </form>

              </div>
            </div>


          </div>
        </div>

    </div>
</div>
</div><?php /**PATH /home/grulovic/video_gov/resources/views/gallery/list_card.blade.php ENDPATH**/ ?>


<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
   

 <div class="row  m-0 p-0">
  
  <div class="col-lg-12  text-left">
    <h2>History List:</h2>
  </div>

</div>


     <?php $__env->endSlot(); ?>

 <div class="row m-0 p-0 pt-5 pb-5">
      <div class="col-md-1"></div>

      <div class="col-md-10 p-0" style="padding-right: 0; overflow-x: auto;">          
        <table class="table table-bordered sortable" id="laravel_crud">
         <thead>
            <tr class="thead-dark">
                <th>ID</th>
                <th>User ID</th>
                <th>User Name</th>

                <th>Item ID</th>
                <th>Item Type</th>
                <th>Item Name</th>
                <th>Action</th>
                
              
                <th>Created at</th>
            </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class=" bg-white " >

              <td><?php echo e($history->id); ?></td>
              <td><?php echo e($history->user_id); ?></td>
              <td><?php echo e($history->user->name); ?></td>
              <td>
                <?php if( $history->video_id == null ): ?>
                  <?php echo e($history->gallery_id); ?>

                <?php else: ?>
                  <?php echo e($history->video_id); ?>

                <?php endif; ?>
              </td>

              <td>
                <?php if( $history->video_id == null ): ?>
                  Photo
                <?php else: ?>
                  Video
                <?php endif; ?>
              </td>
              
              <td>

                <?php if( !isset($history->video_id) ): ?>
                  <?php if($history->gallery !=null): ?>
                  <a href="<?php echo e(route('photos.show', $history->gallery_id  )); ?>">Go to gallery</a>
                  <?php else: ?>
                  Gallery deleted
                  <?php endif; ?>
                <?php else: ?>
                  <?php if($history->video !=null): ?>
                  <a href="<?php echo e(route('videos.show', $history->video_id  )); ?>">Go to video</a>
                  <?php else: ?>
                  Video deleted
                  <?php endif; ?>
                  
                <?php endif; ?>
              </td>
              <td><?php echo e($history->action); ?></td>


              <td><?php echo e($history->created_at); ?></td>
              


              

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
            <?php if(count($histories) < 1): ?>
              <tr class="bg-white">
               <td colspan="13" class="text-center">There are no category available yet!</td>
              </td>
            </tr>
            <?php endif; ?>
         </tbody>
        </table>
        <?php echo $histories->appends(request()->input())->links(); ?>

     </div> 
      <div class="col-md-1"></div>


     


 </div>




  <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /home/grulovic/video_gov/resources/views/history/list.blade.php ENDPATH**/ ?>
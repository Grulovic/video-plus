<?php echo e($slot); ?>

<?php /**PATH /home/grulovic/video_gov/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
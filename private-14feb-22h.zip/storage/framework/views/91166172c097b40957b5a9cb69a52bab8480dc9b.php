<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
 
<div class="row m-0 p-0">
  <div class="col-9">
    <h2>Editing Category <a href="<?php echo e(route('categories.show',$category->id)); ?>"><?php echo e($category->title); ?></a></h2>

  </div>
  <div class="col-3 text-right">
    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-danger mb-2"><i class="fas fa-chevron-left"></i> Go Back</a> 
  </div>    

</div>

 <?php $__env->endSlot(); ?>


<div class="row m-0 p-0 pt-5 pb-5">
<div class="col-md-2"></div>
<div class="col-md-8">
<form class="row" action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST" name="update_category">
  <?php echo e(csrf_field()); ?>

  <?php echo method_field('PATCH'); ?>


  <div class="form-group col-6">
        <strong>Title</strong>
        <input category="text" name="title" class="form-control" placeholder="Enter title" value="<?php echo e($category->title); ?>">
        <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
    </div>


    <div class="form-group col-6">
        <strong>Description</strong>
        <input type="text" name="description" class="form-control" placeholder="Enter description" value="<?php echo e($category->description); ?>">
        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
    </div>





<div class="col-12 pt-3">
        <div class="w-50 float-left p-1">
            <button type="submit" class="btn btn-primary w-100"><i class="far fa-edit"></i> Edit category</button>
        </div>

        <div class="w-50 float-left p-1">
            <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-danger w-100"><i class="fas fa-ban"></i> Cancel edit</a> 
        </div>
    </div>

</form>

</div>

<div class="col-md-2"></div>

</div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /Users/grulovic/code/video-gov/resources/views/category/edit.blade.php ENDPATH**/ ?>
<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', 'HomeController@index')->name("home.index");

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');


Route::get('/videos/list', 'VideoController@list')->name("videos.list");
Route::get('/videos/{video}/download', 'VideoController@download')->name("videos.download");
Route::resource('videos', VideoController::class);




Route::delete('/photos/{photo}/destroy_photo', 'GalleryController@destroy_photo')->name("photos.destroy_photo");
Route::get('/photos/list', 'GalleryController@list')->name("photos.list");
Route::get('/photos/{photo}/download', 'GalleryController@download')->name("photos.download");
Route::resource('photos', GalleryController::class);

Route::resource('categories', CategoryController::class);

Route::get('/history', 'HistoryController@index')->name("history.index");
// Route::resource('histories', HistoryController::class);
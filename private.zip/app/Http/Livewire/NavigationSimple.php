<?php

namespace App\Http\Livewire;

use Livewire\Component;

class NavigationSimple extends Component
{
    public function render()
    {
        return view('livewire.navigation-simple');
    }
}

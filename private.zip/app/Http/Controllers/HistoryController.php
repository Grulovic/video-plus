<?php

namespace App\Http\Controllers;

use App\Models\History;
use Illuminate\Http\Request;

class HistoryController extends Controller
{
    public function index()
    {
        if( auth()->user()->type == "admin" ){
            $data['histories'] = History::orderBy('id','desc')->paginate(10);
        }else{
            $data['histories'] = History::orderBy('id','desc')->where('user_id','=',auth()->user()->id)->paginate(10);
        }

        return view('history.list',$data);
    }
}

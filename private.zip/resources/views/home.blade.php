<x-home-layout>

@include('home.carousel')



	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Latest Videos:</h2>
				<p>These are the latest videos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="{{route('videos.index')}}">Show latest videos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			@foreach($latest_videos as $video)
				@include('home.video_card')
			@endforeach
	</div>


<hr>


	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Latest Photos:</h2>
				<p>These are the latest photos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="{{route('photos.index')}}">Show latest photos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			@foreach($latest_photos as $gallery)
				@include('home.photo_card')
			@endforeach
	</div>
  
  <hr>
  	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Videos from Category 1:</h2>
				<p>These are the latest videos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="{{route('videos.index')}}">Show Category 1 videos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			@foreach($latest_videos as $video)
				@include('home.video_card')
			@endforeach
	</div>


<hr>
	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Photos from Category 1:</h2>
				<p>These are the latest photos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="{{route('photos.index')}}">Show Category 1 photos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			@foreach($latest_photos as $gallery)
				@include('home.photo_card')
			@endforeach
	</div>
  
  <hr>


  	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Most Downloaded Videos:</h2>
				<p>These are the latest videos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="{{route('videos.index')}}">Show latest videos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			@foreach($latest_videos as $video)
				@include('home.video_card')
			@endforeach
	</div>


<hr>

	<div class="row m-0 p-0 pt-4 pb-3">
		<div class="col-lg-12 my-auto">
			<div class="float-left">
				<h2>Most Downloaded Photos:</h2>
				<p>These are the latest photos uploaded.</p>
			</div>
			<div class="float-right mt-2">
				<a class="btn btn-outline-primary" href="{{route('photos.index')}}">Show latest photos <i class="fas fa-angle-right"></i></a>
			</div>
		</div>
			@foreach($latest_photos as $gallery)
				@include('home.photo_card')
			@endforeach
	</div>
  
  <hr>


</x-home-layout>
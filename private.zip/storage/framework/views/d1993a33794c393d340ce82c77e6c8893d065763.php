<a href="/">
    <img src="<?php echo e(asset('video-gov-logo.png')); ?>" style="max-height: 100px; ">
</a>
<?php /**PATH /Users/grulovic/code/video-gov/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>